import React, { useState } from 'react';
import axios from 'axios';

const formatOptions = [
  "Cardio Vascular",
  "Strength Training",
  "Group Classes",
  "Aqua Exercises",
  "Steam Bath",
  "HIIT - Cross Fit"
];

export default function GymForm() {
  const [formData, setFormData] = useState({
    name: '',
    tagline: '',
    address: '',
    owner_mobile: '',
    formats: []
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormatsChange = (e) => {
    const { value, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      formats: checked
        ? [...prev.formats, value]
        : prev.formats.filter(f => f !== value)
    }));
  };

const handleSubmit = async (e) => {
  e.preventDefault();

  const payload = {
    name: formData.name.trim(),
    tagline: formData.tagline.trim(),
    address: formData.address.trim(),
    owner_mobile: formData.owner_mobile.trim(),
    formats: formData.formats || []  // Ensuring it's always an array
  };

  try {
	console.log("Payload being sent:", payload);
    const response = await axios.post('http://127.0.0.1:8000/gyms', payload, {
      headers: { 'Content-Type': 'application/json' }
    });
    alert('Gym created successfully!');
    console.log(response.data);
} catch (error) {
  console.error("Full Axios error object:", error);
  if (error.response) {
    console.error("Backend response data:", JSON.stringify(error.response.data, null, 2));
    alert(`Error: ${JSON.stringify(error.response.data.detail, null, 2)}`);
  } else {
    console.error("Axios error (no response):", error.message);
  }
  alert('Error creating gym.');
}
};

  return (
    <form onSubmit={handleSubmit} className="p-4">
      <h2 className="text-xl font-bold mb-2">Create New Gym</h2>
      <input type="text" name="name" placeholder="Gym Name" onChange={handleChange} className="block border p-2 mb-2 w-full" />
      <input type="text" name="tagline" placeholder="Tagline" onChange={handleChange} className="block border p-2 mb-2 w-full" />
      <input type="text" name="address" placeholder="Address" onChange={handleChange} className="block border p-2 mb-2 w-full" />
      <input type="text" name="owner_mobile" placeholder="Owner Mobile" onChange={handleChange} className="block border p-2 mb-2 w-full" />

      <div className="mb-4">
        <label className="font-bold">Formats:</label>
        {formatOptions.map((format, index) => (
          <div key={index}>
            <label>
              <input
                type="checkbox"
                value={format}
                checked={formData.formats.includes(format)}
                onChange={handleFormatsChange}
              />{' '}
              {format}
            </label>
          </div>
        ))}
      </div>

      <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Create Gym</button>
    </form>
  );
}

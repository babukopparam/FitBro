import React, { useState, useEffect } from 'react';
import axios from 'axios';

function ExercisePlan() {
  const [gymId, setGymId] = useState('');
  const [memberId, setMemberId] = useState('');
  const [cycleNumber, setCycleNumber] = useState('');
  const [masterExercises, setMasterExercises] = useState([]);
  const [selectedExercises, setSelectedExercises] = useState([]);
  const [message, setMessage] = useState('');
  const [openGroups, setOpenGroups] = useState({}); // For collapsible sections

  useEffect(() => {
    const fetchExercises = async () => {
      try {
        const response = await axios.get('http://localhost:8000/exercise-plan');
        setMasterExercises(response.data.exercises);
      } catch (error) {
        console.error('Error loading exercises:', error);
      }
    };

    fetchExercises();
  }, []);

  const groupExercises = () => {
    const grouped = {};
    masterExercises.forEach((exercise) => {
      const key = `Day ${exercise.day} - ${exercise.focus}`;
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(exercise);
    });
    return grouped;
  };

  const handleCheckboxChange = (exerciseObj) => {
    setSelectedExercises((prev) =>
      prev.some((e) => e.exercise === exerciseObj.exercise)
        ? prev.filter((e) => e.exercise !== exerciseObj.exercise)
        : [...prev, exerciseObj]
    );
  };

  const toggleGroup = (groupKey) => {
    setOpenGroups((prev) => ({
      ...prev,
      [groupKey]: !prev[groupKey],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!gymId || !memberId || !cycleNumber || selectedExercises.length === 0) {
      alert('Please fill all fields and select at least one exercise.');
      return;
    }

    try {
      await axios.post(`/gyms/${gymId}/members/${memberId}/exercise-plan`, {
        cycle_number: cycleNumber,
        exercises: selectedExercises,
      });
      setMessage('Exercise plan submitted successfully!');
    } catch (error) {
      console.error(error);
      setMessage('Error submitting plan. Please try again.');
    }
  };

  const groupedExercises = groupExercises();

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Create Exercise Plan</h2>
      <form onSubmit={handleSubmit} className="space-y-4">

        <div>
          <label className="block">Gym ID:</label>
          <input
            type="text"
            value={gymId}
            onChange={(e) => setGymId(e.target.value)}
            className="border p-2 w-full"
            required
          />
        </div>

        <div>
          <label className="block">Member ID:</label>
          <input
            type="text"
            value={memberId}
            onChange={(e) => setMemberId(e.target.value)}
            className="border p-2 w-full"
            required
          />
        </div>

        <div>
          <label className="block">Cycle Number:</label>
          <input
            type="number"
            value={cycleNumber}
            onChange={(e) => setCycleNumber(e.target.value)}
            className="border p-2 w-full"
            required
          />
        </div>

        <div>
          <label className="block mb-2 font-semibold">Select Exercises:</label>
          {Object.entries(groupedExercises).map(([groupKey, exercises]) => (
            <div key={groupKey} className="border rounded mb-3">
              <button
                type="button"
                onClick={() => toggleGroup(groupKey)}
                className="w-full text-left p-2 bg-gray-200 font-medium"
              >
                {groupKey} {openGroups[groupKey] ? '▲' : '▼'}
              </button>

              {openGroups[groupKey] && (
                <div className="p-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {exercises.map((exercise, idx) => (
                    <label
                      key={`${exercise.exercise}-${exercise.day}-${idx}`}
                      className="flex items-center space-x-2 border p-2 rounded"
                    >
                      <input
                        type="checkbox"
                        checked={selectedExercises.some((e) => e.exercise === exercise.exercise)}
                        onChange={() => handleCheckboxChange(exercise)}
                      />
                      <span>
                        <strong>{exercise.exercise}</strong> — {exercise.equipment}
                        <br />
                        <small className="text-gray-600">
                          B: {exercise.beginner} | I: {exercise.intermediate} | E: {exercise.expert}
                        </small>
                      </span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Submit Plan
        </button>

        {message && (
          <div className="mt-4 text-green-600 font-semibold">{message}</div>
        )}
      </form>
    </div>
  );
}

export default ExercisePlan;

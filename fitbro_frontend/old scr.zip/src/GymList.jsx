import React, { useEffect, useState } from 'react';
import axios from 'axios';

const GymList = () => {
  const [gyms, setGyms] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/gyms')
      .then(res => setGyms(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="mb-6">
      <h2 className="text-xl font-semibold mb-2">All Gyms</h2>
      <ul className="list-disc pl-5">
        {gyms.map(gym => (
          <li key={gym.id}>{gym.name} - {gym.tagline}</li>
        ))}
      </ul>
    </div>
  );
};

export default GymList;

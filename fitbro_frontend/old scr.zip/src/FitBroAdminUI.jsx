import React, { useEffect, useState } from "react";
import axios from "axios";

export default function FitBroAdminUI() {
  const [gyms, setGyms] = useState([]);
  const [visitors, setVisitors] = useState([]);
  const [members, setMembers] = useState([]);
  const [assessments, setAssessments] = useState([]);
  const [exercises, setExercises] = useState([]);
  const [plans, setPlans] = useState([]);

  const [gymForm, setGymForm] = useState({ name: "", location: "" });
  const [visitorForm, setVisitorForm] = useState({
    first_name: "",
    last_name: "",
    mobile: "",
    email: "",
    fitness_goal: "cardio",
    decision: "Joining the gym",
    gym_id: ""
  });
  const [memberForm, setMemberForm] = useState({
    first_name: "",
    last_name: "",
    mobile: "",
    email: "",
    fitness_goal: "cardio",
    payment_status: "paid",
    valid_from: "",
    valid_to: "",
    govt_id_type: "aadhar",
    govt_id_number: "",
    validated_by: "instructor",
    gym_id: ""
  });
  const [assessmentForm, setAssessmentForm] = useState({
    member_id: "",
    cycle_number: 1,
    height: 0,
    weight: 0,
    bmi: 0,
    age: 0,
    squats: 0,
    treadmill_distance: 0,
    plank_duration: 0,
    pushups: 0,
    lunges: 0,
    cycling_distance: 0,
    single_leg_stand: 0
  });
  const [exercisePlanForm, setExercisePlanForm] = useState({
    member_id: "",
    cycle_number: 1,
    day_number: 1,
    exercise_id: "",
    sets: 3,
    reps: 10,
    weight: 0,
    notes: ""
  });

  const fitnessGoals = ["fat_loss", "flexibility", "cardio", "muscle", "figure_correction"];
  const decisions = ["Joining the gym", "Will come back later", "Not willing"];
  const govtIDTypes = ["aadhar", "DL", "voter_id", "ration_card", "other"];

  useEffect(() => {
    fetchGyms();
    fetchVisitors();
    fetchMembers();
    fetchAssessments();
    fetchExercises();
    fetchPlans();
  }, []);

  const fetchGyms = async () => setGyms((await axios.get("http://localhost:8000/gyms")).data);
  const fetchVisitors = async () => setVisitors((await axios.get("http://localhost:8000/visitors")).data);
  const fetchMembers = async () => setMembers((await axios.get("http://localhost:8000/members")).data);
  const fetchAssessments = async () => setAssessments((await axios.get("http://localhost:8000/assessments")).data);
  const fetchExercises = async () => setExercises((await axios.get("http://localhost:8000/exercises")).data);
  const fetchPlans = async () => setPlans((await axios.get("http://localhost:8000/exercise-plan")).data);

  const createGym = async () => {
    await axios.post("http://localhost:8000/gyms", gymForm);
    setGymForm({ name: "", location: "" });
    fetchGyms();
  };
  const createVisitor = async () => {
    await axios.post("http://localhost:8000/visitors", visitorForm);
    setVisitorForm({ ...visitorForm, first_name: "", last_name: "", mobile: "", email: "" });
    fetchVisitors();
  };
  const createMember = async () => {
    await axios.post("http://localhost:8000/members", memberForm);
    setMemberForm({ ...memberForm, first_name: "", last_name: "", mobile: "", email: "", govt_id_number: "" });
    fetchMembers();
  };
  const createAssessment = async () => {
    await axios.post("http://localhost:8000/assessments", assessmentForm);
    fetchAssessments();
  };
  const createPlan = async () => {
    await axios.post("http://localhost:8000/exercise-plan", exercisePlanForm);
    setExercisePlanForm({ ...exercisePlanForm, exercise_id: "", sets: 3, reps: 10, weight: 0, notes: "" });
    fetchPlans();
  };

  const renderInput = (label, value, onChange, type = "text") => (
    <div className="flex items-center space-x-4 mb-6">
      <label className="w-1/3 text-sm font-medium text-gray-700 text-center">{label}</label>
      <input type={type} className="border p-2 w-1/3 rounded" value={value} onChange={onChange} />
      <div className="w-1/3" />
    </div>
  );

  const renderSelect = (label, value, onChange, options) => (
    <div className="flex items-center space-x-4 mb-6">
      <label className="w-1/3 text-sm font-medium text-gray-700 text-center">{label}</label>
      <select className="border p-2 w-1/3 rounded" value={value} onChange={onChange}>
        <option value="">Select {label}</option>
        {options.map((opt) => (
          <option key={opt.id || opt} value={opt.id || opt}>{opt.name || opt}</option>
        ))}
      </select>
      <div className="w-1/3" />
    </div>
  );

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-12">
      <h1 className="text-3xl font-bold mb-4 text-blue-800">🏋️ FitBro Admin Console</h1>

      {/* GYM Section */}
      <section className="bg-white p-6 rounded shadow border">
        <h2 className="text-xl font-semibold mb-6 border-b pb-2">Create Gym</h2>
        {renderInput("Gym Name", gymForm.name, (e) => setGymForm({ ...gymForm, name: e.target.value }))}
        {renderInput("Location", gymForm.location, (e) => setGymForm({ ...gymForm, location: e.target.value }))}
        <div className="flex mt-8">
          <div className="w-1/3" />
          <button className="bg-blue-600 text-white px-6 py-2 rounded" onClick={createGym}>Add Gym</button>
        </div>
        <ul className="mt-6 text-sm list-disc pl-5">
          {gyms.map((g) => <li key={g.id}>🏢 {g.name} — {g.location}</li>)}
        </ul>
      </section>

      {/* VISITOR Section */}
      <section className="bg-white p-6 rounded shadow border">
        <h2 className="text-xl font-semibold mb-6 border-b pb-2">Add Visitor</h2>
        {renderInput("First Name", visitorForm.first_name, (e) => setVisitorForm({ ...visitorForm, first_name: e.target.value }))}
        {renderInput("Last Name", visitorForm.last_name, (e) => setVisitorForm({ ...visitorForm, last_name: e.target.value }))}
        {renderInput("Mobile", visitorForm.mobile, (e) => setVisitorForm({ ...visitorForm, mobile: e.target.value }))}
        {renderInput("Email", visitorForm.email, (e) => setVisitorForm({ ...visitorForm, email: e.target.value }))}
        {renderSelect("Fitness Goal", visitorForm.fitness_goal, (e) => setVisitorForm({ ...visitorForm, fitness_goal: e.target.value }), fitnessGoals)}
        {renderSelect("Decision", visitorForm.decision, (e) => setVisitorForm({ ...visitorForm, decision: e.target.value }), decisions)}
        {renderSelect("Gym", visitorForm.gym_id, (e) => setVisitorForm({ ...visitorForm, gym_id: e.target.value }), gyms)}
        <div className="flex mt-8">
          <div className="w-1/3" />
          <button className="bg-green-600 text-white px-6 py-2 rounded" onClick={createVisitor}>Save Visitor</button>
        </div>
      </section>

      {/* MEMBER Section */}
      <section className="bg-white p-6 rounded shadow border">
        <h2 className="text-xl font-semibold mb-6 border-b pb-2">Enroll Member</h2>
        {Object.entries(memberForm).map(([k, v]) => (
          k === "fitness_goal" ? renderSelect("Fitness Goal", v, (e) => setMemberForm({ ...memberForm, [k]: e.target.value }), fitnessGoals)
            : k === "govt_id_type" ? renderSelect("Govt ID Type", v, (e) => setMemberForm({ ...memberForm, [k]: e.target.value }), govtIDTypes)
            : k === "gym_id" ? renderSelect("Gym", v, (e) => setMemberForm({ ...memberForm, [k]: e.target.value }), gyms)
            : renderInput(k.replaceAll("_", " "), v, (e) => setMemberForm({ ...memberForm, [k]: e.target.value }))
        ))}
        <div className="flex mt-8">
          <div className="w-1/3" />
          <button className="bg-purple-600 text-white px-6 py-2 rounded" onClick={createMember}>Save Member</button>
        </div>
      </section>

      {/* ASSESSMENT Section */}
      <section className="bg-white p-6 rounded shadow border">
        <h2 className="text-xl font-semibold mb-6 border-b pb-2">Fitness Assessment</h2>
        {Object.entries(assessmentForm).map(([k, v]) => (
          renderInput(k.replaceAll("_", " "), v, (e) => setAssessmentForm({ ...assessmentForm, [k]: e.target.value }))
        ))}
        <div className="flex mt-8">
          <div className="w-1/3" />
          <button className="bg-indigo-600 text-white px-6 py-2 rounded" onClick={createAssessment}>Add Assessment</button>
        </div>
      </section>

      {/* EXERCISE PLANNER Section */}
      <section className="bg-white p-6 rounded shadow border">
        <h2 className="text-xl font-semibold mb-6 border-b pb-2">Exercise Planner</h2>
        {Object.entries(exercisePlanForm).map(([k, v]) => (
          k === "member_id" ? renderSelect("Member", v, (e) => setExercisePlanForm({ ...exercisePlanForm, [k]: e.target.value }), members)
            : k === "exercise_id" ? renderSelect("Exercise", v, (e) => setExercisePlanForm({ ...exercisePlanForm, [k]: e.target.value }), exercises)
            : renderInput(k.replaceAll("_", " "), v, (e) => setExercisePlanForm({ ...exercisePlanForm, [k]: e.target.value }))
        ))}
        <div className="flex mt-8">
          <div className="w-1/3" />
          <button className="bg-teal-600 text-white px-6 py-2 rounded" onClick={createPlan}>Assign Exercise</button>
        </div>
      </section>
    </div>
  );
}

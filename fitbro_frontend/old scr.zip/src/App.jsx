// App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

import GymList from './GymList';
import GymForm from './GymForm';
import VisitorList from './VisitorList';
import VisitorForm from './VisitorForm';
import ExercisePlan from './ExercisePlan';
import FitBroAdminUI from './FitBroAdminUI';

function App() {
  return (
    <Router>
      <div className="flex h-screen">
        {/* Sidebar */}
        <div className="w-1/4 bg-gray-800 text-white p-4">
          <h1 className="text-2xl font-bold mb-4">🏋️‍♂️ FitBro Admin</h1>
          <nav className="flex flex-col space-y-2">
            <Link to="/gyms" className="hover:bg-gray-600 p-2 rounded">View Gyms</Link>
            <Link to="/add-gym" className="hover:bg-gray-600 p-2 rounded">Add Gym</Link>
            <Link to="/visitors" className="hover:bg-gray-600 p-2 rounded">View Visitors</Link>
            <Link to="/add-visitor" className="hover:bg-gray-600 p-2 rounded">Add Visitor</Link>
            <Link to="/exercise-plan" className="hover:bg-gray-600 p-2 rounded">Exercise Plan</Link>
<Link to="/adminui" className="hover:bg-gray-600 p-2 rounded">Admin UI</Link>
          </nav>
        </div>

        {/* Main Content */}
        <div className="w-3/4 p-6 overflow-y-auto">
          <Routes>
            <Route path="/gyms" element={<GymList />} />
            <Route path="/add-gym" element={<GymForm />} />

            <Route path="/adminui" element={<FitBroAdminUI />} />

            <Route path="/visitors" element={<VisitorList />} />
            <Route path="/add-visitor" element={<VisitorForm />} />
            <Route path="/exercise-plan" element={<ExercisePlan />} />
            <Route path="*" element={<div className="text-gray-500">🎉 Select a page from the left</div>} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;

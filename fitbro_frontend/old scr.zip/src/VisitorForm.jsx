import React, { useState } from 'react';
import axios from 'axios';

const VisitorForm = () => {
  const [form, setForm] = useState({
    mobile: '',
    first_name: '',
    last_name: '',
    email: '',
    fitness_goal: '',
    address: '',
    decision: '',
    gym_id: '',
  });

  const decisions = [
    { value: 'Joining Now', label: 'Joining Now' },
    { value: 'later', label: 'Will Come Back Later' },
    { value: 'not_interested', label: 'Not Interested' }
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { gym_id, ...visitorData } = form;
      if (!gym_id) {
        alert('Gym ID is required');
        return;
      }

      const response = await axios.post(
        `http://127.0.0.1:8000/gyms/${gym_id}/visitors`,
        visitorData
      );
      alert('Visitor created!');
      console.log(response.data);
    } catch (error) {
  console.error("Full Axios error object:", error);
  if (error.response) {
    console.error("Backend response data:", JSON.stringify(error.response.data, null, 2));
    alert(`Error: ${JSON.stringify(error.response.data.detail, null, 2)}`);
  } else {
    console.error("Axios error (no response):", error.message);
  }
  alert('Error creating visitor.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mb-6 p-4 border rounded bg-white shadow-md max-w-md mx-auto">
      <h2 className="text-xl font-semibold mb-4 text-center">Add Visitor</h2>

      <input
        className="input"
        placeholder="Mobile"
        value={form.mobile}
        onChange={e => setForm({ ...form, mobile: e.target.value })}
        required
      />
      <input
        className="input"
        placeholder="First Name"
        value={form.first_name}
        onChange={e => setForm({ ...form, first_name: e.target.value })}
      />
      <input
        className="input"
        placeholder="Last Name"
        value={form.last_name}
        onChange={e => setForm({ ...form, last_name: e.target.value })}
      />
      <input
        className="input"
        placeholder="Email"
        value={form.email}
        onChange={e => setForm({ ...form, email: e.target.value })}
      />
      <input
        className="input"
        placeholder="Fitness Goal"
        value={form.fitness_goal}
        onChange={e => setForm({ ...form, fitness_goal: e.target.value })}
      />
      <input
        className="input"
        placeholder="Address"
        value={form.address}
        onChange={e => setForm({ ...form, address: e.target.value })}
      />

      <select
        className="input"
        value={form.decision}
        onChange={e => setForm({ ...form, decision: e.target.value })}
      >
        {decisions.map(option => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>

      <input
        className="input"
        placeholder="Gym ID"
        value={form.gym_id}
        onChange={e => setForm({ ...form, gym_id: e.target.value })}
        required
      />

      <button type="submit" className="btn mt-4 w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">
        Submit
      </button>
    </form>
  );
};

export default VisitorForm;

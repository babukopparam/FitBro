import React, { useEffect, useState } from 'react';
import axios from 'axios';

const VisitorList = () => {
  const [visitors, setVisitors] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/visitors')
      .then(res => setVisitors(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="mb-6">
      <h2 className="text-xl font-semibold mb-2">All Visitors</h2>
      <ul className="list-disc pl-5">
        {visitors.map(v => (
          <li key={v.mobile}>{v.first_name} {v.last_name} ({v.mobile})</li>
        ))}
      </ul>
    </div>
  );
};

export default VisitorList;

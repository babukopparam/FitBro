import React, { useState } from 'react';
import axios from 'axios';

function AssessmentForm() {
  const [gymId, setGymId] = useState('');
  const [memberId, setMemberId] = useState('');
  const [form, setForm] = useState({
    height_cm: '',
    weight_kg: '',
    age: '',
    squats_per_min: '',
    treadmill_distance_10min_km: '',
    plank_duration_sec: '',
    pushups_one_cycle: '',
    lunges_one_go: '',
    cycling_distance_10min_km: '',
    single_leg_stand_sec: ''
  });
  const [message, setMessage] = useState('');

  const calculateBMI = () => {
    const height_m = parseFloat(form.height_cm) / 100;
    const weight = parseFloat(form.weight_kg);
    return weight && height_m ? (weight / (height_m * height_m)).toFixed(2) : '';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const bmi = calculateBMI();

    try {
      await axios.post(`/gyms/${gymId}/members/${memberId}/assessments`, {
        ...form,
        bmi: parseFloat(bmi),
        assessment_date: new Date().toISOString().slice(0, 10)
      });
      setMessage('Assessment submitted successfully!');
    } catch (error) {
      console.error(error);
      setMessage('Error submitting assessment.');
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Member Assessment Form</h2>
      <form onSubmit={handleSubmit} className="space-y-4">

        <div>
          <label>Gym ID</label>
          <input type="text" value={gymId} onChange={e => setGymId(e.target.value)} required className="border p-2 w-full" />
        </div>

        <div>
          <label>Member ID</label>
          <input type="text" value={memberId} onChange={e => setMemberId(e.target.value)} required className="border p-2 w-full" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div><label>Height (cm)</label><input name="height_cm" value={form.height_cm} onChange={handleChange} type="number" required className="border p-2 w-full" /></div>
          <div><label>Weight (kg)</label><input name="weight_kg" value={form.weight_kg} onChange={handleChange} type="number" required className="border p-2 w-full" /></div>
          <div><label>Age</label><input name="age" value={form.age} onChange={handleChange} type="number" required className="border p-2 w-full" /></div>
          <div><label>BMI</label><input value={calculateBMI()} readOnly className="border p-2 w-full bg-gray-100" /></div>
        </div>

        <hr />

        <h3 className="font-semibold mt-4">Activity Capabilities</h3>
        <div className="grid grid-cols-2 gap-4">
          <div><label>Squats / min</label><input name="squats_per_min" value={form.squats_per_min} onChange={handleChange} type="number" className="border p-2 w-full" /></div>
          <div><label>Treadmill Distance (10 min, km)</label><input name="treadmill_distance_10min_km" value={form.treadmill_distance_10min_km} onChange={handleChange} type="number" step="0.1" className="border p-2 w-full" /></div>
          <div><label>Plank Duration (sec)</label><input name="plank_duration_sec" value={form.plank_duration_sec} onChange={handleChange} type="number" className="border p-2 w-full" /></div>
          <div><label>Pushups (one cycle)</label><input name="pushups_one_cycle" value={form.pushups_one_cycle} onChange={handleChange} type="number" className="border p-2 w-full" /></div>
          <div><label>Lunges (one go)</label><input name="lunges_one_go" value={form.lunges_one_go} onChange={handleChange} type="number" className="border p-2 w-full" /></div>
          <div><label>Cycling Distance (10 min, km)</label><input name="cycling_distance_10min_km" value={form.cycling_distance_10min_km} onChange={handleChange} type="number" step="0.1" className="border p-2 w-full" /></div>
          <div><label>Single Leg Stand (sec)</label><input name="single_leg_stand_sec" value={form.single_leg_stand_sec} onChange={handleChange} type="number" className="border p-2 w-full" /></div>
        </div>

        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded mt-4">Submit Assessment</button>
      </form>

      {message && <div className="mt-4 text-green-600 font-semibold">{message}</div>}
    </div>
  );
}

export default AssessmentForm;

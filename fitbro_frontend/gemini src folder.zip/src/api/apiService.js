// src/api/apiService.js
import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000'; // Your backend URL

// Gyms API
export const fetchGyms = async () => {
    try {
        const response = await axios.get(`${API_BASE_URL}/gyms`);
        return response.data;
    } catch (error) {
        console.error("Error fetching gyms:", error);
        throw new Error("Failed to retrieve gym data.");
    }
};

// Members API
export const fetchMembers = async () => {
    try {
        const response = await axios.get(`${API_BASE_URL}/members`);
        return response.data;
    } catch (error) {
        console.error("Error fetching members:", error);
        throw new Error("Failed to retrieve member data.");
    }
};

// Formats API
export const fetchFormats = async () => {
    try {
        const response = await axios.get(`${API_BASE_URL}/formats`);
        return response.data;
    } catch (error) {
        console.error("Error fetching formats:", error);
        throw new Error("Failed to retrieve format data.");
    }
};

// Workouts API
export const fetchWorkoutsByFormat = async (formatId) => {
    try {
        const response = await axios.get(`${API_BASE_URL}/workouts/by-format/${formatId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching workouts for format ${formatId}:`, error);
        throw new Error("Failed to retrieve workouts for selected format.");
    }
};

export const fetchExercisesByWorkout = async (workoutId) => {
    try {
        const response = await axios.get(`${API_BASE_URL}/workouts/${workoutId}/exercises`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching exercises for workout ${workoutId}:`, error);
        throw new Error("Failed to retrieve exercises for selected workout.");
    }
};

// Exercise Plan API
export const fetchExercisePlan = async (memberId, cycleNumber) => {
    try {
        const response = await axios.get(`${API_BASE_URL}/exercise-plan/member/${memberId}/cycle/${cycleNumber}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching exercise plan for member ${memberId}, cycle ${cycleNumber}:`, error);
        throw new Error("Failed to retrieve exercise plan.");
    }
};

export const saveExercisePlanBulk = async (planEntries) => {
    try {
        const response = await axios.post(`${API_BASE_URL}/exercise-plan/bulk`, planEntries);
        return response.data;
    } catch (error) {
        console.error("Error saving exercise plan:", error);
        throw new Error("Failed to save exercise plan.");
    }
};

// Workout Logs API
export const fetchWorkoutLogs = async () => {
    try {
        const response = await axios.get(`${API_BASE_URL}/workout-logs`);
        return response.data;
    } catch (error) {
        console.error("Error fetching workout logs:", error);
        throw new Error("Failed to retrieve workout logs.");
    }
};

export const logWorkout = async (logData) => {
    try {
        const response = await axios.post(`${API_BASE_URL}/workout-logs`, logData);
        return response.data;
    } catch (error) {
        console.error("Error logging workout:", error);
        throw new Error("Failed to log workout.");
    }
};

// Exercises API
export const fetchExercises = async () => {
    try {
        const response = await axios.get(`${API_BASE_URL}/exercises`);
        return response.data;
    } catch (error) {
        console.error("Error fetching exercises:", error);
        throw new Error("Failed to retrieve exercises.");
    }
};

export const createExercise = async (exerciseData) => {
    try {
        const response = await axios.post(`${API_BASE_URL}/exercises`, exerciseData);
        return response.data;
    } catch (error) {
        console.error("Error creating exercise:", error);
        throw new Error("Failed to create exercise.");
    }
};
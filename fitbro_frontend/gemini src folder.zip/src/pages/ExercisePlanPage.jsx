// src/pages/ExercisePlanPage.jsx
import React from 'react';
import ExercisePlanForm from '../components/ExercisePlanForm'; // Assuming you move this file

function ExercisePlanPage() {
  return (
    <div className="container mx-auto p-8">
      <ExercisePlanForm />
    </div>
  );
}

export default ExercisePlanPage;
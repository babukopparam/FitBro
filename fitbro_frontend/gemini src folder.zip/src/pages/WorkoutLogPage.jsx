// src/pages/WorkoutLogPage.jsx
import React from 'react';
import WorkoutLogForm from '../components/WorkoutLogForm'; // Assuming you move this file

function WorkoutLogPage() {
  return (
    <div className="container mx-auto p-8">
      <WorkoutLogForm />
    </div>
  );
}

export default WorkoutLogPage;
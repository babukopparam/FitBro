// src/pages/HomePage.jsx
import React from 'react';
import HeroSection from '../components/HeroSection';

function HomePage() {
    return (
        <>
            <HeroSection />
            <div className="container mx-auto p-8">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-800 text-center mb-8">Why Choose GymApp?</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition duration-300">
                        {/* Icons are set to w-8 h-8 */}
                        <svg className="w-8 h-8 mx-auto mb-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"></path><path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd"></path></svg>
                        <h3 className="text-xl font-semibold text-gray-800 mb-2">Extensive Database</h3>
                        <p className="text-gray-600">Access a vast collection of gyms and fitness centers across the country.</p>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition duration-300">
                        {/* Icons are set to w-8 h-8 */}
                        <svg className="w-8 h-8 mx-auto mb-4 text-green-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                        <h3 className="text-xl font-semibold text-gray-800 mb-2">Verified Information</h3>
                        <p className="text-gray-600">We provide up-to-date and reliable information on each facility.</p>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition duration-300">
                        {/* Icons are set to w-8 h-8 */}
                        <svg className="w-8 h-8 mx-auto mb-4 text-purple-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 002-2V4H4zm10 10v2a2 2 0 002 2h4v-2a2 2 0 00-2-2h-4zM2 10v4a2 2 0 002 2h4v-2a2 2 0 00-2-2H2z" clipRule="evenodd"></path></svg>
                        <h3 className="text-xl font-semibold text-gray-800 mb-2">User Reviews & Ratings</h3>
                        <p className="text-gray-600">Make informed decisions with feedback from our community.</p>
                    </div>
                </div>
            </div>
        </>
    );
}

export default HomePage;
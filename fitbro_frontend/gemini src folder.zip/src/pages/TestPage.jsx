// src/pages/TestPage.jsx
import React from 'react';

function TestPage() {
    return (
        <div className="bg-blue-100 p-8 rounded-lg shadow-xl text-center">
            <h2 className="text-blue-700 text-5xl font-extrabold mb-4">This is the Test Page!</h2>
            <p className="text-blue-600 text-lg">If you see this, routing is working.</p>
        </div>
    );
}

export default TestPage;
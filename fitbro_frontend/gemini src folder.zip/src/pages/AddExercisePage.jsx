// src/pages/AddExercisePage.jsx
import React from 'react';
import ExerciseForm from '../components/ExerciseForm'; // Assuming you move this file

function AddExercisePage() {
  return (
    <div className="container mx-auto p-8">
      <ExerciseForm />
    </div>
  );
}

export default AddExercisePage;
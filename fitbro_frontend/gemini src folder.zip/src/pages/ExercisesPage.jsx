// src/pages/ExercisesPage.jsx
import React from 'react';
import ExerciseList from '../components/ExerciseList'; // Assuming you move this file

function ExercisesPage() {
  return (
    <div className="container mx-auto p-8">
      <ExerciseList />
    </div>
  );
}

export default ExercisesPage;
// src/pages/GymListPage.jsx
import React, { useEffect, useState } from "react";
import { fetchGyms } from '../api/apiService';
import GymCard from '../components/GymCard'; // Import GymCard

function GymListPage() {
  const [gyms, setGyms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterLocation, setFilterLocation] = useState("");
  const [filteredGyms, setFilteredGyms] = useState([]);

  // Mock Data (replace with real data structure from your backend if different)
  // This is to make the GymCard look richer until your backend provides more details
  const mockGymData = [
    {
      id: 1,
      name: "Powerhouse Gym",
      location: "Koramangala, Bengaluru",
      imageUrl: "https://images.unsplash.com/photo-1579758778434-d621f375005b?fit=crop&w=800&q=80",
      description: "A state-of-the-art facility with modern equipment, personal trainers, and a wide range of classes including yoga, Zumba, and CrossFit.",
      amenities: ["Cardio Machines", "Weight Training", "Group Classes", "Personal Training", "Locker Rooms", "Showers"]
    },
    {
      id: 2,
      name: "Fitness First Express",
      location: "Indiranagar, Bengaluru",
      imageUrl: "https://images.unsplash.com/photo-1544367527-2c99a2d8a571?fit=crop&w=800&q=80",
      description: "Conveniently located with express workout zones, focusing on quick and effective training sessions. Ideal for busy professionals.",
      amenities: ["Cardio Machines", "Free Weights", "Express Workouts", "Spin Studio"]
    },
    {
      id: 3,
      name: "The Iron Paradise",
      location: "Jayanagar, Bengaluru",
      imageUrl: "https://images.unsplash.com/photo-1599058917215-a92265007ee2?fit=crop&w=800&q=80",
      description: "A haven for serious weightlifters and powerlifters. Specializes in heavy lifting equipment and strength training programs.",
      amenities: ["Power Racks", "Olympic Lifting Platforms", "Dumbbells (heavy)", "Strength Coaching"]
    },
    {
      id: 4,
      name: "Zen Yoga & Pilates Studio",
      location: "Malleshwaram, Bengaluru",
      imageUrl: "https://images.unsplash.com/photo-1552594615-5463f8582f6e?fit=crop&w=800&q=80",
      description: "Dedicated studio for mind-body wellness. Offers various styles of yoga, Pilates, and meditation classes in a serene environment.",
      amenities: ["Yoga Studio", "Pilates Equipment", "Meditation Space", "Changing Rooms"]
    },
    {
      id: 5,
      name: "CrossFit Central",
      location: "HSR Layout, Bengaluru",
      imageUrl: "https://images.unsplash.com/photo-1571008892182-3d842d0a0b6d?fit=crop&w=800&q=80",
      description: "High-intensity functional training with a strong community focus. Suitable for all fitness levels, led by certified coaches.",
      amenities: ["CrossFit Boxes", "Functional Training Area", "Certified Coaches", "Community Events"]
    }
  ];


  useEffect(() => {
    const getGyms = async () => {
      try {
        setLoading(true);
        // In a real app, you'd fetch from your API:
        // const data = await fetchGyms();
        // setGyms(data);

        // For now, use mock data and simulate network delay
        setTimeout(() => {
          setGyms(mockGymData);
          setFilteredGyms(mockGymData); // Initialize filtered gyms
          setLoading(false);
        }, 1000); // Simulate 1 second loading
      } catch (err) {
        setError(err.message || "Failed to load gyms.");
        setLoading(false);
      }
    };

    getGyms();
  }, []);

  // Filter and search logic
  useEffect(() => {
    let currentGyms = gyms;

    if (searchTerm) {
      currentGyms = currentGyms.filter(gym =>
        gym.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        gym.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterLocation) {
      currentGyms = currentGyms.filter(gym =>
        gym.location.toLowerCase().includes(filterLocation.toLowerCase())
      );
    }

    setFilteredGyms(currentGyms);
  }, [searchTerm, filterLocation, gyms]); // Re-run when these dependencies change

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleLocationChange = (e) => {
    setFilterLocation(e.target.value);
  };

  // Get unique locations for the filter dropdown
  const uniqueLocations = [...new Set(gyms.map(gym => gym.location))];

  return (
    <div className="container mx-auto p-8">
      <h2 className="text-4xl font-extrabold text-gray-900 text-center mb-10">Discover Your Next Gym</h2>

      {/* Search and Filter Section */}
      <div className="bg-white p-6 rounded-lg shadow-md mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
        <input
          type="text"
          placeholder="Search by gym name or description..."
          className="p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200 text-lg"
          value={searchTerm}
          onChange={handleSearchChange}
        />
        <select
          className="p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200 text-lg"
          value={filterLocation}
          onChange={handleLocationChange}
        >
          <option value="">All Locations</option>
          {uniqueLocations.map((loc) => (
            <option key={loc} value={loc}>{loc}</option>
          ))}
        </select>
      </div>

      {loading && (
        <div className="flex flex-col justify-center items-center h-64 bg-white rounded-lg shadow-md">
          <div className="animate-spin rounded-full h-20 w-20 border-t-4 border-b-4 border-blue-500"></div>
          <p className="ml-4 text-xl text-gray-700 mt-4">Loading amazing gyms for you...</p>
        </div>
      )}

      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded mb-6" role="alert">
          <p className="font-bold">Oops!</p>
          <p>{error}</p>
        </div>
      )}

      {!loading && !error && (
        <>
          {filteredGyms.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredGyms.map((gym) => (
                <GymCard key={gym.id} gym={gym} />
              ))}
            </div>
          ) : (
            <div className="bg-white p-6 rounded-lg shadow-md text-center text-gray-600 text-xl py-12">
              <p>No gyms found matching your criteria. Try adjusting your search or filters.</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default GymListPage;
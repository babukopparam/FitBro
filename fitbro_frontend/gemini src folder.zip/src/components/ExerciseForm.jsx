// src/components/ExerciseForm.jsx
import React, { useEffect, useState } from "react";
import { fetchFormats, fetchWorkoutsByFormat, createExercise } from '../api/apiService'; // Import from centralized API service

export default function ExerciseForm() {
    const [form, setForm] = useState({
        name: "",
        description: "",
        difficulty_level: "",
        demo_video_url: "",
        active: true, // Default to active
        equipment: "",
        goal_tags: "",
        workout_id: "",
        format_id: ""
    });

    const [formats, setFormats] = useState([]);
    const [workouts, setWorkouts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [successMessage, setSuccessMessage] = useState(null);

    useEffect(() => {
        const loadFormats = async () => {
            setError(null);
            try {
                const fetchedFormats = await fetchFormats();
                setFormats(fetchedFormats);
            } catch (err) {
                console.error("Failed to load formats:", err);
                setError("Failed to load exercise formats.");
            }
        };
        loadFormats();
    }, []);

    const handleFormatChange = async (formatId) => {
        setForm({ ...form, format_id: formatId, workout_id: "" });
        setError(null);
        setWorkouts([]); // Clear workouts when format changes
        if (!formatId) return; // If "Select Format" is chosen

        try {
            const res = await fetchWorkoutsByFormat(formatId);
            setWorkouts(res);
        } catch (err) {
            console.error("Failed to load workouts:", err);
            setError("Failed to load workouts for the selected format.");
        }
    };

    const handleSubmit = async () => {
        setError(null);
        setSuccessMessage(null);
        setLoading(true);

        // Basic validation
        if (!form.name || !form.format_id || !form.workout_id) {
            setError("Please fill in Exercise Name, Format, and Workout.");
            setLoading(false);
            return;
        }

        const payload = {
            name: form.name,
            description: form.description,
            difficulty_level: form.difficulty_level,
            demo_video_url: form.demo_video_url,
            active: form.active,
            equipment: form.equipment,
            goal_tags: form.goal_tags,
            workout_id: form.workout_id ? parseInt(form.workout_id) : null,
        };

        try {
            await createExercise(payload);
            setSuccessMessage("Exercise added successfully!");
            // Reset form
            setForm({
                name: "",
                description: "",
                difficulty_level: "",
                demo_video_url: "",
                active: true,
                equipment: "",
                goal_tags: "",
                workout_id: "",
                format_id: ""
            });
            setWorkouts([]); // Clear workouts after successful submission
        } catch (err) {
            console.error("Error creating exercise:", err);
            setError(err.message || "Failed to create exercise. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="p-6 max-w-xl mx-auto bg-white rounded-lg shadow-xl mb-8">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-6 flex items-center">
                <span className="mr-3 text-blue-600">➕</span> Add New Exercise
            </h2>

            {error && (
                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded mb-6" role="alert">
                    <p className="font-bold">Error:</p>
                    <p>{error}</p>
                </div>
            )}

            {successMessage && (
                <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded mb-6" role="alert">
                    <p className="font-bold">Success!</p>
                    <p>{successMessage}</p>
                </div>
            )}

            <div className="space-y-4">
                {/* Format Dropdown */}
                <div>
                    <label htmlFor="format-select" className="block text-gray-700 text-sm font-bold mb-2">Select Format <span className="text-red-500">*</span></label>
                    <select
                        id="format-select"
                        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        value={form.format_id}
                        onChange={(e) => handleFormatChange(e.target.value)}
                    >
                        <option value="">Choose Format</option>
                        {formats.map(f => (
                            <option key={f.id} value={f.id}>{f.name}</option>
                        ))}
                    </select>
                </div>

                {/* Workout Dropdown */}
                <div>
                    <label htmlFor="workout-select" className="block text-gray-700 text-sm font-bold mb-2">Select Workout <span className="text-red-500">*</span></label>
                    <select
                        id="workout-select"
                        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base disabled:bg-gray-100"
                        value={form.workout_id}
                        onChange={(e) => setForm({ ...form, workout_id: e.target.value })}
                        disabled={!form.format_id || workouts.length === 0}
                    >
                        <option value="">Choose Workout</option>
                        {workouts.map(w => (
                            <option key={w.id} value={w.id}>{w.name}</option>
                        ))}
                    </select>
                </div>

                {/* Input fields */}
                <div>
                    <label htmlFor="exercise-name" className="block text-gray-700 text-sm font-bold mb-2">Exercise Name <span className="text-red-500">*</span></label>
                    <input
                        id="exercise-name"
                        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        placeholder="e.g., Barbell Bench Press"
                        value={form.name}
                        onChange={e => setForm({ ...form, name: e.target.value })}
                    />
                </div>

                <div>
                    <label htmlFor="description" className="block text-gray-700 text-sm font-bold mb-2">Description</label>
                    <textarea
                        id="description"
                        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base resize-y"
                        placeholder="Brief description of the exercise mechanics."
                        value={form.description}
                        onChange={e => setForm({ ...form, description: e.target.value })}
                        rows="3"
                    />
                </div>

                <div>
                    <label htmlFor="difficulty" className="block text-gray-700 text-sm font-bold mb-2">Difficulty Level</label>
                    <input
                        id="difficulty"
                        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        placeholder="e.g., Beginner, Intermediate, Advanced"
                        value={form.difficulty_level}
                        onChange={e => setForm({ ...form, difficulty_level: e.target.value })}
                    />
                </div>

                <div>
                    <label htmlFor="video-url" className="block text-gray-700 text-sm font-bold mb-2">Demo Video URL</label>
                    <input
                        id="video-url"
                        type="url"
                        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        placeholder="https://youtube.com/watch?v=example"
                        value={form.demo_video_url}
                        onChange={e => setForm({ ...form, demo_video_url: e.target.value })}
                    />
                </div>

                <div>
                    <label htmlFor="equipment" className="block text-gray-700 text-sm font-bold mb-2">Equipment Needed</label>
                    <input
                        id="equipment"
                        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        placeholder="e.g., Barbell, Dumbbells, Bench"
                        value={form.equipment}
                        onChange={e => setForm({ ...form, equipment: e.target.value })}
                    />
                </div>

                <div>
                    <label htmlFor="goal-tags" className="block text-gray-700 text-sm font-bold mb-2">Goal Tags (comma separated)</label>
                    <input
                        id="goal-tags"
                        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        placeholder="e.g., Strength, Hypertrophy, Endurance"
                        value={form.goal_tags}
                        onChange={e => setForm({ ...form, goal_tags: e.target.value })}
                    />
                </div>

                <div className="flex items-center">
                    <input
                        id="active-checkbox"
                        type="checkbox"
                        className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        checked={form.active}
                        onChange={e => setForm({ ...form, active: e.target.checked })}
                    />
                    <label htmlFor="active-checkbox" className="ml-2 block text-gray-900 text-sm font-medium">
                        Active Exercise (visible in lists)
                    </label>
                </div>

                <button
                    onClick={handleSubmit}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:bg-gray-400"
                    disabled={loading}
                >
                    {loading ? 'Saving...' : 'Save Exercise'}
                </button>
            </div>
        </div>
    );
}
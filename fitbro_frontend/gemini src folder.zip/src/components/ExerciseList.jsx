// src/components/ExerciseList.jsx
import React, { useEffect, useState } from "react";
import { fetchExercises } from '../api/apiService'; // Import from centralized API service

export default function ExerciseList() {
    const [exercises, setExercises] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadExercises = async () => {
            setLoading(true);
            setError(null);
            try {
                const data = await fetchExercises();
                setExercises(data);
            } catch (err) {
                console.error("Failed to load exercises:", err);
                setError(err.message || "Failed to load exercises list.");
            } finally {
                setLoading(false);
            }
        };
        loadExercises();
    }, []);

    return (
        <div className="p-6 max-w-7xl mx-auto bg-white rounded-lg shadow-xl mb-8">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-6 flex items-center">
                <span className="mr-3 text-blue-600">📋</span> All Exercises
            </h2>

            {error && (
                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded mb-6" role="alert">
                    <p className="font-bold">Error:</p>
                    <p>{error}</p>
                </div>
            )}

            {loading ? (
                <div className="flex flex-col items-center justify-center h-48 bg-gray-50 rounded-lg shadow-inner">
                    <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500 border-opacity-75"></div>
                    <p className="mt-4 text-gray-600 text-lg">Loading exercises...</p>
                </div>
            ) : (
                <div className="overflow-x-auto shadow-md rounded-lg">
                    {exercises.length > 0 ? (
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Format</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Workout</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Difficulty</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Equipment</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Goal Tags</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Demo</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {exercises.map((ex) => (
                                    <tr key={ex.id || ex.name} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{ex.name}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{ex.format?.name || "-"}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{ex.workout?.name || "-"}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{ex.difficulty_level}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{ex.equipment}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{ex.goal_tags}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-600 hover:underline">
                                            {ex.demo_video_url ? (
                                                <a href={ex.demo_video_url} target="_blank" rel="noopener noreferrer">Watch Demo</a>
                                            ) : (
                                                "-"
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <p className="text-center text-gray-600 py-8 text-lg">No exercises found. Add some using the "Add Exercise" form!</p>
                    )}
                </div>
            )}
        </div>
    );
}
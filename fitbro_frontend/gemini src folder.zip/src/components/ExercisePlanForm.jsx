// src/components/ExercisePlanForm.jsx
import React, { useEffect, useState } from "react";
import {
    fetchMembers,
    fetchFormats,
    fetchWorkoutsByFormat,
    fetchExercisesByWorkout,
    fetchExercisePlan,
    saveExercisePlanBulk
} from '../api/apiService'; // Import from centralized API service

export default function ExercisePlanForm() {
    const [members, setMembers] = useState([]);
    const [formats, setFormats] = useState([]);
    const [workouts, setWorkouts] = useState({});
    const [exercisesByWorkout, setExercisesByWorkout] = useState({});
    const [plan, setPlan] = useState({});
    const [selectedMemberId, setSelectedMemberId] = useState("");
    const [cycleNumber, setCycleNumber] = useState(1);
    const [isCompleted, setIsCompleted] = useState(false);
    const [loadingPlan, setLoadingPlan] = useState(false);
    const [errorPlan, setErrorPlan] = useState(null);

    useEffect(() => {
        const loadInitialData = async () => {
            try {
                const fetchedMembers = await fetchMembers();
                setMembers(fetchedMembers);
                const fetchedFormats = await fetchFormats();
                setFormats(fetchedFormats);
            } catch (err) {
                console.error("Failed to load initial data:", err);
                setErrorPlan("Failed to load initial data like members and formats.");
            }
        };
        loadInitialData();
    }, []);

    useEffect(() => {
        if (selectedMemberId && cycleNumber) {
            setLoadingPlan(true);
            setErrorPlan(null);
            const loadPlan = async () => {
                try {
                    const entries = await fetchExercisePlan(selectedMemberId, cycleNumber);
                    setIsCompleted(entries.length > 0 && entries[0].cycle_completed);

                    const newPlan = {};
                    const newWorkouts = {};
                    const newExercises = {};

                    for (const entry of entries) {
                        const day = entry.day_number;
                        if (!newPlan[day]) {
                            newPlan[day] = {
                                workout_id: entry.workout_id,
                                exercises: [],
                                format_id: entry.format?.id || null
                            };
                        }

                        newPlan[day].exercises.push({
                            exercise_id: entry.exercise_id,
                            sets: entry.sets,
                            reps: entry.reps
                        });

                        // Fetch workouts for format (once per day)
                        if (entry.format?.id && !newWorkouts[day]) {
                            try {
                                const workoutsRes = await fetchWorkoutsByFormat(entry.format.id);
                                newWorkouts[day] = workoutsRes;
                            } catch (wErr) {
                                console.error(`Error loading workouts for format ${entry.format.id} on day ${day}:`, wErr);
                            }
                        }

                        // Fetch exercises for workout (once per day)
                        if (entry.workout_id && !newExercises[day]) {
                            try {
                                const exercisesRes = await fetchExercisesByWorkout(entry.workout_id);
                                newExercises[day] = exercisesRes;
                            } catch (eErr) {
                                console.error(`Error loading exercises for workout ${entry.workout_id} on day ${day}:`, eErr);
                            }
                        }
                    }

                    setPlan(newPlan);
                    setWorkouts(newWorkouts);
                    setExercisesByWorkout(newExercises);

                } catch (err) {
                    setPlan({});
                    setIsCompleted(false);
                    setErrorPlan(err.message || "Could not load existing plan.");
                } finally {
                    setLoadingPlan(false);
                }
            };
            loadPlan();
        } else {
            setPlan({});
            setIsCompleted(false);
            setWorkouts({});
            setExercisesByWorkout({});
            setLoadingPlan(false);
            setErrorPlan(null);
        }
    }, [selectedMemberId, cycleNumber]);

    const handleFormatChange = async (formatId, day) => {
        setErrorPlan(null);
        try {
            const res = await fetchWorkoutsByFormat(formatId);
            setWorkouts(prev => ({ ...prev, [day]: res }));
            setPlan(prev => ({
                ...prev,
                [day]: { ...prev[day], workout_id: "", exercises: [], format_id: formatId }
            }));
        } catch (err) {
            setErrorPlan("Failed to load workouts for the selected format.");
        }
    };

    const handleWorkoutChange = async (workoutId, day) => {
        setErrorPlan(null);
        try {
            const res = await fetchExercisesByWorkout(workoutId);
            setExercisesByWorkout(prev => ({ ...prev, [day]: res }));
            setPlan(prev => ({ ...prev, [day]: { ...prev[day], workout_id: workoutId, exercises: [] } }));
        } catch (err) {
            setErrorPlan("Failed to load exercises for the selected workout.");
        }
    };

    const toggleExercise = (day, exercise) => {
        const dayPlan = plan[day] || { exercises: [] };
        const exists = dayPlan.exercises.find(e => e.exercise_id === exercise.id);
        const updated = exists
            ? dayPlan.exercises.filter(e => e.exercise_id !== exercise.id)
            : [...dayPlan.exercises, { exercise_id: exercise.id, sets: 3, reps: 10 }]; // Default sets/reps
        setPlan(prev => ({ ...prev, [day]: { ...dayPlan, exercises: updated } }));
    };

    const updateSetsReps = (day, exerciseId, field, value) => {
        const exercises = plan[day].exercises.map(e =>
            e.exercise_id === exerciseId ? { ...e, [field]: parseInt(value) } : e
        );
        setPlan(prev => ({ ...prev, [day]: { ...prev[day], exercises } }));
    };

    const handleSubmit = async () => {
        setErrorPlan(null);
        const planEntries = [];
        Object.entries(plan).forEach(([day, data]) => {
            if (data.exercises && data.exercises.length > 0) {
                data.exercises.forEach(ex => {
                    planEntries.push({
                        member_id: parseInt(selectedMemberId),
                        cycle_number: parseInt(cycleNumber),
                        day_number: parseInt(day),
                        workout_focus: `Day ${day} Focus`, // You might want to make this dynamic
                        workout_id: data.workout_id,
                        exercise_id: ex.exercise_id,
                        sets: ex.sets,
                        reps: ex.reps,
                        weight: null, // Placeholder
                        notes: null   // Placeholder
                    });
                });
            }
        });

        if (planEntries.length === 0) {
            alert("Please add exercises to the plan before saving.");
            return;
        }

        try {
            await saveExercisePlanBulk(planEntries);
            alert("Exercise plan saved successfully!");
            // Optionally refetch plan to update 'isCompleted' status
            // Or you can manually set it if the backend marks it complete on save
            // For now, simple alert and let user navigate
        } catch (err) {
            console.error(err);
            setErrorPlan(err.message || "Error saving plan.");
        }
    };

    return (
        <div className="p-6 max-w-5xl mx-auto bg-white rounded-lg shadow-xl mb-8">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-6 flex items-center">
                <span className="mr-3 text-blue-600">📝</span> Create Exercise Plan
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div>
                    <label htmlFor="memberSelect" className="block text-gray-700 text-sm font-bold mb-2">Select Member</label>
                    <select
                        id="memberSelect"
                        className="block w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        value={selectedMemberId}
                        onChange={e => setSelectedMemberId(e.target.value)}
                    >
                        <option value="">Choose Member</option>
                        {members.map(m => (
                            <option key={m.id} value={m.id}>
                                {m.first_name} {m.last_name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label htmlFor="cycleSelect" className="block text-gray-700 text-sm font-bold mb-2">Select Cycle</label>
                    <select
                        id="cycleSelect"
                        className="block w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        value={cycleNumber}
                        onChange={e => setCycleNumber(e.target.value)}
                    >
                        {[1, 2, 3, 4, 5].map(n => (
                            <option key={n} value={n}>Cycle {n}</option>
                        ))}
                    </select>
                </div>

                {isCompleted && (
                    <div className="flex items-center justify-center p-3 mt-8 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                        <span className="text-xl mr-2">✅</span>
                        <span className="font-semibold">This cycle is marked as completed!</span>
                    </div>
                )}
            </div>

            {errorPlan && (
                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded mb-6" role="alert">
                    <p className="font-bold">Error:</p>
                    <p>{errorPlan}</p>
                </div>
            )}

            {loadingPlan ? (
                <div className="flex flex-col items-center justify-center h-48 bg-gray-50 rounded-lg shadow-inner">
                    <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500 border-opacity-75"></div>
                    <p className="mt-4 text-gray-600 text-lg">Loading plan details...</p>
                </div>
            ) : (
                <div className="space-y-8">
                    {[...Array(7)].map((_, i) => { // Render 7 days for a typical weekly plan
                        const day = i + 1;
                        const dayPlan = plan[day] || {};
                        const currentFormatId = dayPlan.format_id || "";
                        const currentWorkoutId = dayPlan.workout_id || "";

                        return (
                            <div key={day} className="border border-gray-200 rounded-lg p-6 shadow-sm bg-gray-50">
                                <h3 className="text-xl font-bold text-gray-800 mb-4 pb-2 border-b border-gray-200">Day {day}</h3>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                    <div>
                                        <label htmlFor={`format-${day}`} className="block text-gray-700 text-sm font-medium mb-1">Select Format</label>
                                        <select
                                            id={`format-${day}`}
                                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-200"
                                            disabled={isCompleted}
                                            value={currentFormatId}
                                            onChange={e => handleFormatChange(e.target.value, day)}
                                        >
                                            <option value="">Choose Format</option>
                                            {formats.map(f => (
                                                <option key={f.id} value={f.id}>{f.name}</option>
                                            ))}
                                        </select>
                                    </div>

                                    <div>
                                        <label htmlFor={`workout-${day}`} className="block text-gray-700 text-sm font-medium mb-1">Select Workout</label>
                                        <select
                                            id={`workout-${day}`}
                                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-200"
                                            disabled={isCompleted || !currentFormatId}
                                            value={currentWorkoutId}
                                            onChange={e => handleWorkoutChange(e.target.value, day)}
                                        >
                                            <option value="">Choose Workout</option>
                                            {(workouts[day] || []).map(w => (
                                                <option key={w.id} value={w.id}>{w.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                </div>

                                <div className="mt-6 border-t pt-4 border-gray-200">
                                    <h4 className="text-md font-semibold text-gray-700 mb-3">Exercises for this Workout:</h4>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-y-3 gap-x-6">
                                        {(exercisesByWorkout[day] || []).length > 0 ? (
                                            (exercisesByWorkout[day] || []).map(ex => {
                                                const selected = (dayPlan.exercises || []).find(e => e.exercise_id === ex.id);
                                                return (
                                                    <div key={ex.id} className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 p-2 bg-white rounded-md shadow-sm border border-gray-100">
                                                        <div className="flex items-center flex-grow">
                                                            <input
                                                                id={`ex-<span class="math-inline">\{day\}\-</span>{ex.id}`}
                                                                type="checkbox"
                                                                disabled={isCompleted}
                                                                checked={!!selected}
                                                                onChange={() => toggleExercise(day, ex)}
                                                                className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded cursor-pointer"
                                                            />
                                                            <label htmlFor={`ex-<span class="math-inline">\{day\}\-</span>{ex.id}`} className="ml-3 text-gray-800 font-medium text-lg cursor-pointer">
                                                                {ex.name}
                                                            </label>
                                                            <span className="ml-2 text-sm text-gray-500 italic hidden sm:block">({ex.description})</span>
                                                        </div>
                                                        {selected && (
                                                            <div className="flex space-x-2 w-full sm:w-auto mt-2 sm:mt-0">
                                                                <label className="sr-only" htmlFor={`sets-<span class="math-inline">\{day\}\-</span>{ex.id}`}>Sets</label>
                                                                <input
                                                                    id={`sets-<span class="math-inline">\{day\}\-</span>{ex.id}`}
                                                                    type="number"
                                                                    placeholder="Sets"
                                                                    aria-label="Sets"
                                                                    className="w-full sm:w-20 p-2 border border-gray-300 rounded-md text-center disabled:bg-gray-100"
                                                                    disabled={isCompleted}
                                                                    value={selected.sets}
                                                                    onChange={e => updateSetsReps(day, ex.id, "sets", e.target.value)}
                                                                    min="1"
                                                                />
                                                                <label className="sr-only" htmlFor={`reps-<span class="math-inline">\{day\}\-</span>{ex.id}`}>Reps</label>
                                                                <input
                                                                    id={`reps-<span class="math-inline">\{day\}\-</span>{ex.id}`}
                                                                    type="number"
                                                                    placeholder="Reps"
                                                                    aria-label="Reps"
                                                                    className="w-full sm:w-20 p-2 border border-gray-300 rounded-md text-center disabled:bg-gray-100"
                                                                    disabled={isCompleted}
                                                                    value={selected.reps}
                                                                    onChange={e => updateSetsReps(day, ex.id, "reps", e.target.value)}
                                                                    min="1"
                                                                />
                                                            </div>
                                                        )}
                                                    </div>
                                                );
                                            })
                                        ) : (
                                            currentWorkoutId ? (
                                                <p className="text-gray-500 italic col-span-full">No exercises available for this workout.</p>
                                            ) : (
                                                <p className="text-gray-500 italic col-span-full">Select a workout to see exercises.</p>
                                            )
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}


            {!isCompleted && !loadingPlan && (
                <button
                    onClick={handleSubmit}
                    className="mt-8 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                    Save Plan
                </button>
            )}
        </div>
    );
}
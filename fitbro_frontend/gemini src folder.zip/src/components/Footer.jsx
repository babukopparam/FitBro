// src/components/Footer.jsx
import React from 'react';

function Footer() {
    const currentYear = new Date().getFullYear();
    return (
        <footer className="bg-gray-900 text-white py-8 px-4">
            <div className="container mx-auto text-center">
                <div className="mb-4">
                    <h3 className="text-2xl font-bold text-blue-400 mb-2">GymApp</h3>
                    <p className="text-gray-400">Your ultimate guide to fitness centers.</p>
                </div>
                <div className="flex justify-center space-x-6 mb-4">
                    <a href="#" className="text-gray-300 hover:text-blue-400 transition duration-300">About Us</a>
                    <a href="#" className="text-gray-300 hover:text-blue-400 transition duration-300">Contact</a>
                    <a href="#" className="text-gray-300 hover:text-blue-400 transition duration-300">Privacy Policy</a>
                </div>
                <p className="text-gray-500 text-sm">
                    &copy; {currentYear} GymApp. All rights reserved.
                </p>
            </div>
        </footer>
    );
}

export default Footer;
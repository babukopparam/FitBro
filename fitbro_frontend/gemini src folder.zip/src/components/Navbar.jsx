// src/components/Navbar.jsx (Temporary Test Version)
import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
    return (
        <nav className="bg-gray-900 text-white shadow-lg py-4 px-8 flex justify-between items-center">
            <Link to="/" className="text-3xl font-bold text-blue-400 hover:text-blue-300">
                GymApp Test
            </Link>
            <div>
                <Link to="/" className="mr-6 hover:text-blue-400 text-lg font-medium">Home Test</Link>
                <Link to="/test" className="hover:text-blue-400 text-lg font-medium">Go to Test Page</Link>
            </div>
        </nav>
    );
}

export default Navbar;
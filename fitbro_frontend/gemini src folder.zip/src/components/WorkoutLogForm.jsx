// src/components/WorkoutLogForm.jsx
import React, { useEffect, useState, useMemo } from "react";
import { fetchMembers, fetchExercisePlan, fetchWorkoutLogs, logWorkout } from '../api/apiService'; // Import from centralized API service

export default function WorkoutLogForm() {
    const [members, setMembers] = useState([]);
    const [selectedMemberId, setSelectedMemberId] = useState("");
    const [cycleNumber, setCycleNumber] = useState(1);
    const [planEntries, setPlanEntries] = useState([]);
    const [workoutLogs, setWorkoutLogs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadMembers = async () => {
            try {
                const fetchedMembers = await fetchMembers();
                setMembers(fetchedMembers);
            } catch (err) {
                console.error("Failed to load members:", err);
                setError("Failed to load members list.");
            }
        };
        loadMembers();
    }, []);

    useEffect(() => {
        const loadData = async () => {
            if (selectedMemberId && cycleNumber) {
                setLoading(true);
                setError(null);
                try {
                    const fetchedPlanEntries = await fetchExercisePlan(selectedMemberId, cycleNumber);
                    setPlanEntries(fetchedPlanEntries);

                    // Optimally, workout logs should be fetched per member/cycle if your API supports it
                    // For now, fetching all logs and filtering client-side
                    const fetchedLogs = await fetchWorkoutLogs();
                    setWorkoutLogs(fetchedLogs);
                } catch (err) {
                    console.error("Failed to load workout data:", err);
                    setError(err.message || "Failed to load workout plan or logs.");
                    setPlanEntries([]);
                    setWorkoutLogs([]);
                } finally {
                    setLoading(false);
                }
            } else {
                setPlanEntries([]);
                setWorkoutLogs([]);
                setLoading(false);
                setError(null);
            }
        };
        loadData();
    }, [selectedMemberId, cycleNumber]);

    const getExercisesForDay = (day) => {
        return planEntries.filter(e => e.day_number === day);
    };

    const getWorkoutName = (entries) => {
        const names = new Set(entries.map(e => e.workout?.name).filter(Boolean));
        return Array.from(names).join(", ");
    };

    const getLastLoggedDate = (logs) => {
        if (!logs || logs.length === 0) return "N/A";
        const dates = logs.map(l => new Date(l.date));
        const latest = new Date(Math.max(...dates));
        return latest.toLocaleDateString('en-GB'); // Format for DD/MM/YYYY
    };

    const getDayStatus = useMemo(() => {
        return (entries) => {
            // Filter logs relevant to the current member and cycle, and entries on this specific day
            const dayPlanEntryIds = entries.map(e => e.id);
            const relevantDayLogs = workoutLogs.filter(log =>
                log.member_id === parseInt(selectedMemberId) &&
                dayPlanEntryIds.includes(log.plan_entry_id)
            );

            if (entries.length === 0) return { label: "Exercises not defined", color: "text-gray-500" };

            const completedLogsCount = relevantDayLogs.filter(log => log.status === "done").length;

            if (completedLogsCount === entries.length) {
                const latestDate = getLastLoggedDate(relevantDayLogs);
                return { label: `Completed on ${latestDate}`, color: "text-green-600" };
            }

            if (relevantDayLogs.length > 0) {
                const latestDate = getLastLoggedDate(relevantDayLogs);
                return { label: `Partial (last: ${latestDate})`, color: "text-yellow-600" };
            }

            return { label: "To be started", color: "text-blue-600" };
        };
    }, [workoutLogs, selectedMemberId]);


    const handleLogChange = async (plan_entry_id, status) => {
        setError(null);
        const date = new Date().toISOString().split("T")[0]; // YYYY-MM-DD

        try {
            // Check if a log already exists for this plan_entry_id and member for today
            const existingLog = workoutLogs.find(
                log => log.member_id === parseInt(selectedMemberId) &&
                       log.plan_entry_id === plan_entry_id &&
                       log.date === date
            );

            if (existingLog) {
                // Update existing log
                await axios.put(`http://localhost:8000/workout-logs/${existingLog.id}`, { status });
            } else {
                // Create new log
                await logWorkout({
                    member_id: parseInt(selectedMemberId),
                    plan_entry_id,
                    date,
                    status
                });
            }

            alert("Workout log updated successfully!");
            // Re-fetch logs to update UI
            const updatedLogs = await fetchWorkoutLogs();
            setWorkoutLogs(updatedLogs);

        } catch (err) {
            console.error("Error logging workout:", err);
            setError(err.message || "Error logging workout.");
        }
    };

    const allDays = [...new Set(planEntries.map(e => e.day_number))].sort((a, b) => a - b);
    // If no plan entries, show up to 10 days as before to allow creating
    const daysToRender = allDays.length > 0 ? allDays : [...Array(10)].map((_, i) => i + 1);

    return (
        <div className="p-6 max-w-4xl mx-auto bg-white rounded-lg shadow-xl mb-8">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-6 flex items-center">
                <span className="mr-3 text-blue-600">💪</span> Log Your Workout
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                    <label htmlFor="memberSelectLog" className="block text-gray-700 text-sm font-bold mb-2">Select Member</label>
                    <select
                        id="memberSelectLog"
                        className="block w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        value={selectedMemberId}
                        onChange={e => setSelectedMemberId(e.target.value)}
                    >
                        <option value="">Choose Member</option>
                        {members.map(m => (
                            <option key={m.id} value={m.id}>
                                {m.first_name} {m.last_name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label htmlFor="cycleSelectLog" className="block text-gray-700 text-sm font-bold mb-2">Select Cycle</label>
                    <select
                        id="cycleSelectLog"
                        className="block w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base"
                        value={cycleNumber}
                        onChange={e => setCycleNumber(e.target.value)}
                    >
                        {[1, 2, 3, 4, 5].map(num => (
                            <option key={num} value={num}>Cycle {num}</option>
                        ))}
                    </select>
                </div>
            </div>

            {error && (
                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded mb-6" role="alert">
                    <p className="font-bold">Error:</p>
                    <p>{error}</p>
                </div>
            )}

            {loading ? (
                <div className="flex flex-col items-center justify-center h-48 bg-gray-50 rounded-lg shadow-inner">
                    <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500 border-opacity-75"></div>
                    <p className="mt-4 text-gray-600 text-lg">Loading workout data...</p>
                </div>
            ) : (
                <div className="space-y-6">
                    {daysToRender.map((day) => {
                        const entries = getExercisesForDay(day);
                        const workoutName = getWorkoutName(entries);
                        const statusInfo = getDayStatus(entries);

                        // Only render days that actually have exercises defined or for which data is being loaded/selected
                        if (entries.length === 0 && selectedMemberId && planEntries.length > 0) {
                            return null; // Skip days with no exercises if a plan is loaded
                        }

                        return (
                            <div key={day} className="border border-gray-200 rounded-lg p-6 shadow-sm bg-gray-50">
                                <h3 className="text-xl font-bold text-gray-800 mb-3 pb-2 border-b border-gray-200">
                                    Day {day} {workoutName && `- ${workoutName}`}
                                    <span className={`${statusInfo.color} font-semibold ml-3 text-base`}>
                                        ({statusInfo.label})
                                    </span>
                                </h3>

                                {entries.length > 0 ? (
                                    <div className="overflow-x-auto">
                                        <table className="min-w-full text-sm bg-white border border-gray-200 rounded-md">
                                            <thead className="bg-gray-100">
                                                <tr>
                                                    <th className="p-3 text-left font-medium text-gray-700">Exercise</th>
                                                    <th className="p-3 text-center font-medium text-gray-700">Sets</th>
                                                    <th className="p-3 text-center font-medium text-gray-700">Reps</th>
                                                    <th className="p-3 text-center font-medium text-gray-700">Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {entries.map(entry => {
                                                    // Find the most recent log for this plan entry and selected member
                                                    const existingLogsForEntry = workoutLogs.filter(
                                                        log => log.plan_entry_id === entry.id && log.member_id === parseInt(selectedMemberId)
                                                    );
                                                    const existingLog = existingLogsForEntry.length > 0
                                                        ? existingLogsForEntry.reduce((latest, current) =>
                                                            new Date(latest.date) > new Date(current.date) ? latest : current
                                                        )
                                                        : null;

                                                    return (
                                                        <tr key={entry.id} className="border-t border-gray-100 hover:bg-gray-50">
                                                            <td className="p-3 font-medium text-gray-800">{entry.exercise?.name}</td>
                                                            <td className="p-3 text-center text-gray-700">{entry.sets}</td>
                                                            <td className="p-3 text-center text-gray-700">{entry.reps}</td>
                                                            <td className="p-3 text-center">
                                                                <select
                                                                    value={existingLog?.status || "to be started"}
                                                                    onChange={(e) => handleLogChange(entry.id, e.target.value)}
                                                                    className="border border-gray-300 px-3 py-2 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm"
                                                                    disabled={!selectedMemberId} // Disable if no member is selected
                                                                >
                                                                    <option value="to be started">To be started</option>
                                                                    <option value="done">Done</option>
                                                                    <option value="partial">Partial</option>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : (
                                    <p className="text-gray-500 italic p-2">
                                        {selectedMemberId && planEntries.length === 0 ? "No plan defined for this member/cycle." : "No exercises defined for this day."}
                                    </p>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
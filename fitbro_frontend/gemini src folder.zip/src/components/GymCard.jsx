// src/components/GymCard.jsx
import React from 'react';

function GymCard({ gym }) {
    return (
        <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <img
                src={gym.image_url || `https://via.placeholder.com/400x250?text=${gym.name.replace(/\s/g, '+')}`}
                alt={gym.name}
                className="w-full h-48 object-cover"
            />
            <div className="p-4">
                <h3 className="text-xl font-bold text-gray-800 mb-2">{gym.name}</h3>
                <p className="text-gray-600 text-sm mb-2">{gym.address}, {gym.city}</p>
                <div className="flex items-center text-yellow-500 mb-2">
                    {Array(Math.floor(gym.rating)).fill().map((_, i) => (
                        <svg key={i} className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M12 .587l3.692 7.568 8.308 1.207-6.001 5.855 1.416 8.272L12 18.896l-7.415 3.905 1.416-8.272-6.001-5.855 8.308-1.207L12 .587z" /></svg>
                    ))}
                    {gym.rating % 1 !== 0 && (
                        <svg className="w-5 h-5 fill-current text-gray-300" viewBox="0 0 24 24"><path d="M12 .587l3.692 7.568 8.308 1.207-6.001 5.855 1.416 8.272L12 18.896l-7.415 3.905 1.416-8.272-6.001-5.855 8.308-1.207L12 .587z" /></svg>
                    )}
                    <span className="ml-1 text-gray-700">({gym.rating})</span>
                </div>
                <p className="text-gray-700 mb-3">{gym.description.substring(0, 100)}...</p>
                <div className="flex flex-wrap gap-2 mb-3">
                    {gym.amenities && gym.amenities.map((amenity, index) => (
                        <span key={index} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">{amenity}</span>
                    ))}
                </div>
                <a href={`/gyms/${gym.id}`} className="block bg-blue-600 text-white text-center py-2 px-4 rounded-md hover:bg-blue-700 transition duration-300">
                    View Details
                </a>
            </div>
        </div>
    );
}

export default GymCard;
// src/components/HeroSection.jsx
import React from 'react';
import { Link } from 'react-router-dom';

function HeroSection() {
    return (
        <div className="relative bg-gradient-to-r from-gray-900 to-gray-700 text-white py-20 px-8 text-center overflow-hidden">
            <div className="absolute inset-0 z-0 opacity-20">
                {/* Background image or pattern */}
                <div className="bg-cover bg-center h-full w-full" style={{ backgroundImage: "url('https://via.placeholder.com/1500x800/2C3E50/FFFFFF?text=Fitness+Background')" }}></div>
            </div>
            <div className="relative z-10 max-w-4xl mx-auto">
                <h1 className="text-5xl md:text-6xl font-extrabold leading-tight mb-6 animate-fade-in-down">
                    Find Your Perfect Gym, Anywhere, Anytime.
                </h1>
                <p className="text-lg md:text-xl mb-10 animate-fade-in-up">
                    Discover top-rated fitness centers, compare amenities, and kickstart your fitness journey today!
                </p>
                <Link
                    to="/gyms"
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full text-lg transition duration-300 transform hover:scale-105 animate-zoom-in"
                >
                    Explore Gyms Now
                </Link>
            </div>
        </div>
    );
}

export default HeroSection;
﻿// src/App.jsx (Temporary Test Version)
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar'; // Keep Navbar for navigation test
import HomePage from './pages/HomePage'; // Keep for now to see its default state
import TestPage from './pages/TestPage';   // NEW: For specific test

function App() {
    return (
        <Router>
            <div className="min-h-screen flex flex-col bg-gray-100">
                <Navbar />
                <main className="flex-grow flex items-center justify-center p-8">
                    <Routes>
                        {/* We'll use this route for a very basic Tailwind test */}
                        <Route
                            path="/"
                            element={
                                <div className="bg-yellow-200 p-6 rounded-lg shadow-lg">
                                    <h1 className="text-red-500 text-4xl font-bold">Hello World!</h1>
                                    <p className="mt-4 text-gray-700">This is a simple test message.</p>
                                </div>
                            }
                        />
                        {/* Test for routing */}
                        <Route path="/test" element={<TestPage />} />
                        {/* Fallback for other routes */}
                        <Route path="*" element={<h1 className="text-4xl text-center p-20 text-red-600">404 - Page Not Found!</h1>} />
                    </Routes>
                </main>
            </div>
        </Router>
    );
}

export default App;
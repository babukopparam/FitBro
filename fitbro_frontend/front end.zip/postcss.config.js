// postcss.config.js
export default {
  plugins: {
    // Change 'tailwindcss' to '@tailwindcss/postcss'
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};
// AnnouncementsPage.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function AnnouncementsPage({ gymId }) {
  const [announcements, setAnnouncements] = useState([]);

  useEffect(() => {
    axios
      .get(`http://localhost:8000/gyms/${gymId}/announcements`)
      .then((res) => setAnnouncements(res.data))
      .catch((err) => console.error("Failed to load announcements", err));
  }, [gymId]);

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-center mb-6">📢 Announcements</h2>
      {announcements.length === 0 ? (
        <p className="text-gray-500 text-center">No announcements available.</p>
      ) : (
        <div className="space-y-4">
          {announcements.map((a, index) => (
            <div key={index} className="bg-white rounded shadow p-4">
              <h3 className="text-lg font-semibold">{a.title}</h3>
              <p className="text-sm text-gray-600 mb-2">
                {new Date(a.created_at).toLocaleDateString()}
              </p>
              <p className="text-gray-700">{a.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

export default function WeeklySummaryPage() {
    const { memberId } = useParams();
    const [summary, setSummary] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        axios.get(`http://localhost:8000/members/${memberId}/weekly-summary`)
            .then(res => setSummary(res.data))
            .catch(err => console.error("Error fetching summary", err))
            .finally(() => setLoading(false));
    }, [memberId]);

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-3xl mx-auto bg-white rounded shadow p-6">
                <h2 className="text-2xl font-bold mb-4">📊 Weekly Summary</h2>

                {loading ? (
                    <p>Loading summary...</p>
                ) : summary ? (
                    <div className="space-y-4">
                        <div className="text-lg">
                            <strong>Total Workout Days:</strong> {summary.total_days_logged}
                        </div>
                        <div className="text-lg">
                            <strong>Most Frequent Workout:</strong> {summary.most_frequent_workout}
                        </div>
                        <div className="text-lg">
                            <strong>Current Streak:</strong> {summary.workout_streak} days
                        </div>
                    </div>
                ) : (
                    <p className="text-red-500">Unable to load summary.</p>
                )}
            </div>
        </div>
    );
}

﻿import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

export default function LogWorkoutForDay() {
    const { memberId, cycleNumber, dayNumber } = useParams();
    const [entries, setEntries] = useState([]);
    const [memberName, setMemberName] = useState("");
    const [toastMessage, setToastMessage] = useState("");

    const fetchData = async () => {
        try {
            const memberRes = await axios.get(`http://localhost:8000/members/${memberId}`);
            const fullName = `${memberRes.data.first_name ?? ""} ${memberRes.data.last_name ?? ""}`.trim();
            setMemberName(fullName);

            const res = await axios.get(
                `http://localhost:8000/workout-logs/plan-details?member_id=${memberId}&cycle=${cycleNumber}&day=${dayNumber}`
            );
            setEntries(res.data);
        } catch (err) {
            console.error("Error fetching workout plan", err);
        }
    };

    useEffect(() => {
        fetchData();
    }, [memberId, cycleNumber, dayNumber]);

    const showToast = (message) => {
        setToastMessage(message);
        setTimeout(() => setToastMessage(""), 2500);
    };

    const handleChange = (index, field, value) => {
        setEntries(prev => {
            const updated = [...prev];
            updated[index] = { ...updated[index], [field]: value };
            return updated;
        });
    };

    const markCompleted = async (index) => {
        const updated = [...entries];
        updated[index].status = "completed";

        try {
            await axios.post("http://localhost:8000/workout-logs/log-bulk", {
                member_id: parseInt(memberId),
                cycle: parseInt(cycleNumber),
                day: parseInt(dayNumber),
                logs: [updated[index]]
            });
            showToast(`${updated[index].exercise_name} marked as completed`);
            await fetchData(); // Refresh after updating
        } catch (err) {
            console.error("Failed to mark completed", err);
            showToast("Failed to update workout");
        }
    };

    const renderSubHeaders = (entry) =>
        entry.is_time_based ? (
            <>
                <th className="text-center">Minutes</th>
                <th className="text-center">Minutes</th>
            </>
        ) : (
            <>
                <th className="text-center">Sets</th>
                <th className="text-center">Reps</th>
                <th className="text-center">Sets</th>
                <th className="text-center">Reps</th>
            </>
        );

    const renderRow = (entry, index) => {
        const isCompleted = entry.status === "completed";

        return (
            <tr key={entry.exercise_id} className="border-t">
                <td className="px-4 py-2 font-medium">{entry.exercise_name}</td>

                {entry.is_time_based ? (
                    <>
                        <td className="text-center">{entry.planned_time_minutes ?? "-"}</td>
                        <td className="text-center">
                            {isCompleted ? (
                                <span>{entry.actual_time_minutes ?? "-"}</span>
                            ) : (
                                <input
                                    type="number"
                                    value={entry.actual_time_minutes || ""}
                                    onChange={(e) =>
                                        handleChange(index, "actual_time_minutes", parseFloat(e.target.value))
                                    }
                                    className="w-20 border px-1 rounded"
                                />
                            )}
                        </td>
                    </>
                ) : (
                    <>
                        <td className="text-center">{entry.planned_sets ?? "-"}</td>
                        <td className="text-center">{entry.planned_reps ?? "-"}</td>
                        <td className="text-center">
                            {isCompleted ? (
                                <span>{entry.actual_sets ?? "-"}</span>
                            ) : (
                                <input
                                    type="number"
                                    value={entry.actual_sets || ""}
                                    onChange={(e) =>
                                        handleChange(index, "actual_sets", parseInt(e.target.value))
                                    }
                                    className="w-16 border px-1 rounded"
                                />
                            )}
                        </td>
                        <td className="text-center">
                            {isCompleted ? (
                                <span>{entry.actual_reps ?? "-"}</span>
                            ) : (
                                <input
                                    type="number"
                                    value={entry.actual_reps || ""}
                                    onChange={(e) =>
                                        handleChange(index, "actual_reps", parseInt(e.target.value))
                                    }
                                    className="w-16 border px-1 rounded"
                                />
                            )}
                        </td>
                    </>
                )}

                <td className="text-center">
                    {isCompleted ? (
                        <span className="text-green-600 font-semibold">Completed</span>
                    ) : (
                        <button
                            onClick={() => markCompleted(index)}
                            className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
                        >
                            Mark Completed
                        </button>
                    )}
                </td>
            </tr>
        );
    };

    return (
        <div className="min-h-screen bg-gray-50 p-8 relative">
            <div className="max-w-5xl mx-auto">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">
                    Log Workout - {memberName} | Cycle {cycleNumber} - Day {dayNumber}
                </h2>

                {entries.length === 0 ? (
                    <p className="text-gray-600">No exercises found for today.</p>
                ) : (
                    <table className="w-full table-auto bg-white rounded shadow-md">
                        <thead className="bg-gray-200 text-sm text-gray-700">
                            <tr>
                                <th className="px-4 py-2 text-left">Exercise</th>
                                <th colSpan={entries[0]?.is_time_based ? 2 : 4} className="text-center">
                                    Planned / Worked Out
                                </th>
                                <th className="px-4 py-2 text-center">Status</th>
                            </tr>
                            <tr className="bg-gray-100 text-xs text-gray-600">
                                <th></th>
                                {renderSubHeaders(entries[0])}
                                <th></th>
                            </tr>
                        </thead>
                        <tbody className="text-sm">
                            {entries.map((entry, index) => renderRow(entry, index))}
                        </tbody>
                    </table>
                )}
            </div>

            {toastMessage && (
                <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-black text-white text-sm px-4 py-2 rounded shadow-lg z-50">
                    {toastMessage}
                </div>
            )}
        </div>
    );
}

import React, { useEffect, useState } from "react";
import axios from "axios";

export default function VisitorList() {
  const [visitors, setVisitors] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8000/visitors").then((res) => setVisitors(res.data));
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-xl font-bold mb-4">Visitor List</h2>
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-100">
            <th className="border px-4 py-2">Name</th>
            <th className="border px-4 py-2">Mobile</th>
            <th className="border px-4 py-2">Goal</th>
            <th className="border px-4 py-2">Decision</th>
          </tr>
        </thead>
        <tbody>
          {visitors.map((v) => (
            <tr key={v.id}>
              <td className="border px-4 py-2">{v.first_name} {v.last_name}</td>
              <td className="border px-4 py-2">{v.mobile}</td>
              <td className="border px-4 py-2">{v.fitness_goal}</td>
              <td className="border px-4 py-2">{v.decision}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
// src/pages/LogWorkoutEntryPage.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function LogWorkoutEntryPage() {
  const [members, setMembers] = useState([]);
  const [memberId, setMemberId] = useState("");
  const [cycleNumber, setCycleNumber] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("/members").then((res) => {
      if (Array.isArray(res.data)) {
        setMembers(res.data);
      }
    });
  }, []);

  const handleGoToLog = () => {
    if (memberId && cycleNumber) {
      navigate(`/log-workout/member/${memberId}/cycle/${cycleNumber}`);
    }
  };

  const handleGoToGraph = () => {
    if (memberId) {
      navigate(`/assessment-history/${memberId}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-xl mx-auto space-y-4">
        <h2 className="text-2xl font-bold text-gray-800">🏋️ Log Today's Workout</h2>

        <div>
          <label className="block text-sm font-medium mb-1">Select Member</label>
          <select
            className="w-full border px-3 py-2 rounded"
            value={memberId}
            onChange={(e) => setMemberId(e.target.value)}
          >
            <option value="">-- Select Member --</option>
            {members.map((m) => (
              <option key={m.id} value={m.id}>
                {m.first_name} {m.last_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Select Cycle</label>
          <select
            className="w-full border px-3 py-2 rounded"
            value={cycleNumber}
            onChange={(e) => setCycleNumber(e.target.value)}
          >
            <option value="">-- Select Cycle --</option>
            {[1, 2, 3, 4, 5].map((c) => (
              <option key={c} value={c}>
                Cycle {c}
              </option>
            ))}
          </select>
        </div>

        <div className="flex gap-4 pt-4">
          <button
            onClick={handleGoToLog}
            disabled={!memberId || !cycleNumber}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
          >
            Proceed to Log Workout
          </button>

          <button
            onClick={handleGoToGraph}
            disabled={!memberId}
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
          >
            View Progress Graph
          </button>
        </div>
      </div>
    </div>
  );
}

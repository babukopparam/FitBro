import React, { useEffect, useState } from "react";
import axios from "axios";

function GymList() {
    const [gyms, setGyms] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchGyms = async () => {
            try {
                const response = await axios.get("http://localhost:8000/gyms");
                setGyms(response.data);
            } catch (err) {
                setError("Failed to load gyms. Please try again later.");
                console.error("Error fetching gym data:", err);
            } finally {
                setLoading(false);
            }
        };

        fetchGyms();
    }, []);

    return (
        <div className="min-h-screen bg-gray-100 font-sans">
            {/* Header */}
            <header className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-6 shadow-md">
                <div className="container mx-auto flex justify-between items-center">
                    <h1 className="text-3xl font-bold">Gym Locator</h1>
                    <nav>
                        <ul className="flex space-x-6">
                            <li>
                                <a href="#" className="hover:text-blue-200 transition duration-300">Home</a>
                            </li>
                            <li>
                                <a href="#" className="hover:text-blue-200 transition duration-300">About</a>
                            </li>
                            <li>
                                <a href="#" className="hover:text-blue-200 transition duration-300">Contact</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </header>

            {/* Main Content */}
            <main className="container mx-auto p-8">
                <h2 className="text-4xl font-extrabold text-gray-800 mb-8 text-center">Our Gym Locations</h2>

                {loading && (
                    <div className="flex justify-center items-center h-48">
                        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-500"></div>
                        <p className="ml-4 text-xl text-gray-600">Loading gyms...</p>
                    </div>
                )}

                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                        <strong className="font-bold">Error!</strong>
                        <span className="block sm:inline ml-2">{error}</span>
                    </div>
                )}

                {!loading && !error && (
                    <div className="bg-white shadow-lg rounded-lg overflow-hidden">
                        {gyms.length > 0 ? (
                            <table className="min-w-full leading-normal">
                                <thead>
                                    <tr className="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                                        <th className="py-3 px-6 text-left">Gym Name</th>
                                        <th className="py-3 px-6 text-left">Location</th>
                                        {/* Add more headers for additional gym properties */}
                                    </tr>
                                </thead>
                                <tbody className="text-gray-700 text-sm">
                                    {gyms.map((gym) => (
                                        <tr key={gym.id} className="border-b border-gray-200 hover:bg-gray-100">
                                            <td className="py-3 px-6 text-left whitespace-nowrap">
                                                <div className="flex items-center">
                                                    <div className="text-lg font-medium">{gym.name}</div>
                                                </div>
                                            </td>
                                            <td className="py-3 px-6 text-left">
                                                <div className="text-lg">{gym.location}</div>
                                            </td>
                                            {/* Add more cells for additional gym properties */}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        ) : (
                            <p className="p-6 text-center text-gray-600 text-lg">No gyms found. Please check back later!</p>
                        )}
                    </div>
                )}
            </main>

            {/* Footer */}
            <footer className="bg-gray-800 text-white p-6 mt-12">
                <div className="container mx-auto text-center text-gray-400">
                    <p>&copy; {new Date().getFullYear()} Gym Locator. All rights reserved.</p>
                    <p className="mt-2 text-sm">Designed with <span className="text-red-500">&hearts;</span> for a healthier you.</p>
                </div>
            </footer>
        </div>
    );
}

export default GymList;
import React, { useState, useEffect } from "react";
import axios from "axios";

export default function VisitorForm() {
  const [gyms, setGyms] = useState([]);
  const [form, setForm] = useState({
    first_name: "",
    last_name: "",
    mobile: "",
    email: "",
    fitness_goal: "cardio",
    decision: "Joining the gym",
    gym_id: ""
  });

  useEffect(() => {
    axios.get("http://localhost:8000/gyms").then((res) => setGyms(res.data));
  }, []);

  const handleSubmit = async () => {
    await axios.post("http://localhost:8000/visitors", form);
    alert("Visitor created successfully");
    setForm({ ...form, first_name: "", last_name: "", mobile: "", email: "" });
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-4">Add Visitor</h2>
      {Object.entries(form).map(([key, val]) => (
        key === "fitness_goal" || key === "decision" || key === "gym_id" ? (
          <select
            key={key}
            className="w-full border p-2 mb-4"
            value={val}
            onChange={(e) => setForm({ ...form, [key]: e.target.value })}
          >
            <option value="">Select {key.replaceAll("_", " ")}</option>
            {(key === "gym_id" ? gyms :
              key === "fitness_goal" ? ["cardio", "fat_loss", "muscle"] :
              ["Joining the gym", "Will come back later", "Not willing"]).map((option) => (
              <option key={option.id || option} value={option.id || option}>
                {option.name || option}
              </option>
            ))}
          </select>
        ) : (
          <input
            key={key}
            className="w-full border p-2 mb-4"
            placeholder={key.replaceAll("_", " ")}
            value={val}
            onChange={(e) => setForm({ ...form, [key]: e.target.value })}
          />
        )
      ))}
      <button className="bg-blue-600 text-white px-4 py-2 rounded" onClick={handleSubmit}>
        Save Visitor
      </button>
    </div>
  );
}

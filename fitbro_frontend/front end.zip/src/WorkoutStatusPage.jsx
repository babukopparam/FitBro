// WorkoutStatusPage.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";

function isSunday(date) {
    return dayjs(date).day() === 0;
}

function getPlannedDates(startDate, count) {
    const result = [];
    let current = dayjs(startDate);
    while (result.length < count) {
        if (!isSunday(current)) {
            result.push(current.format("YYYY-MM-DD"));
        }
        current = current.add(1, "day");
    }
    return result;
}

export default function WorkoutStatusPage() {
    const [members, setMembers] = useState([]);
    const [memberId, setMemberId] = useState("");
    const [memberName, setMemberName] = useState("");
    const [cycleNumber, setCycleNumber] = useState("");
    const [statusList, setStatusList] = useState([]);
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        axios.get("http://localhost:8000/members").then((res) => {
            if (Array.isArray(res.data)) {
                setMembers(res.data);
            } else if (Array.isArray(res.data.members)) {
                setMembers(res.data.members);
            } else {
                setMembers([]);
            }
        });
    }, []);

    useEffect(() => {
        if (memberId && cycleNumber) {
            setLoading(true);

            axios.get(`/members/${memberId}`).then((res) => {
                const { first_name, last_name } = res.data;
                setMemberName(`${first_name ?? ""} ${last_name ?? ""}`.trim());
            });

            axios
                .get(`http://localhost:8000/workout-logs/status?member_id=${memberId}&cycle=${cycleNumber}`)
                .then((res) => {
                    console.log("Workout status response:", res.data);
                    setStatusList(res.data);
                })
                .catch((err) => {
                    if (err.response?.status === 404) {
                        setStatusList([]);
                    }
                })
                .finally(() => setLoading(false));
        }
    }, [memberId, cycleNumber]);

    const plannedDates = getPlannedDates(dayjs(), 10);

    const handleClick = (day) => {
        navigate(`/log-workout/member/${memberId}/cycle/${cycleNumber}/day/${day}`);
    };

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-4xl mx-auto space-y-6">
                <div className="flex gap-4">
                    <div className="w-1/2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Select Member</label>
                        <select
                            value={memberId}
                            onChange={(e) => setMemberId(e.target.value)}
                            className="w-full border border-gray-300 rounded px-3 py-2"
                        >
                            <option value="">-- Select --</option>
                            {Array.isArray(members) && members.map((m) => (
                                <option key={m.id} value={m.id}>
                                    {m.first_name} {m.last_name}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="w-1/2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Select Cycle</label>
                        <select
                            value={cycleNumber}
                            onChange={(e) => setCycleNumber(e.target.value)}
                            className="w-full border border-gray-300 rounded px-3 py-2"
                        >
                            <option value="">-- Select --</option>
                            {[...Array(5)].map((_, i) => (
                                <option key={i + 1} value={i + 1}>
                                    Cycle {i + 1}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                {memberId && cycleNumber && (
                    <div>
                        <h2 className="text-xl font-semibold text-gray-800 mb-4">
                            Log Workout: {memberName} | Cycle {cycleNumber}
                        </h2>

                        {loading ? (
                            <p className="text-gray-600">Loading status...</p>
                        ) : statusList.length === 0 ? (
                            <p className="text-gray-500">No exercise plan found for this member and cycle.</p>
                        ) : (
                            <div className="space-y-4">
                                {Array.from({ length: 10 }).map((_, i) => {
                                    const day = i + 1;
                                    const plannedDate = plannedDates[i];
                                    const status = statusList.find((s) => s.day === day);

                                    const workoutNames = status?.workout_names?.length
                                        ? status.workout_names.join(", ")
                                        : "-";

                                    const label = status?.status === "completed"
                                        ? dayjs(status.completed_date).format("DD MMM YYYY")
                                        : null;

                                    return (
                                        <div key={day} className="flex items-center justify-between bg-white p-4 shadow rounded">
                                            <div className="w-1/4 font-medium">Day {day}</div>
                                            <div className="w-1/4 text-sm text-gray-700">{workoutNames}</div>
                                            <div className="w-1/4">
                                                <span className={`px-2 py-1 rounded text-xs ${status?.status === "completed"
                                                        ? "bg-green-100 text-green-800"
                                                        : status?.status === "partial"
                                                            ? "bg-yellow-100 text-yellow-800"
                                                            : "bg-blue-100 text-blue-800"
                                                    }`}>
                                                    {status?.status || "to_be_started"}
                                                </span>
                                            </div>
                                            <div className="w-1/4 text-right">
                                                {status?.status === "completed" ? (
                                                    <span className="text-sm text-gray-500">{label}</span>
                                                ) : (
                                                    <button
                                                        onClick={() => handleClick(day)}
                                                        className="text-sm bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
                                                    >
                                                        Pick up today
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

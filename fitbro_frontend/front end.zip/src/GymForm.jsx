import React, { useState } from "react";
import axios from "axios";

function GymForm() {
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8000/gyms", { name, location });
    setName("");
    setLocation("");
    alert("Gym created!");
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">Create Gym</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Gym Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border p-2 w-1/2"
        />
        <input
          type="text"
          placeholder="Location"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="border p-2 w-1/2 block"
        />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          Save Gym
        </button>
      </form>
    </div>
  );
}

export default GymForm;

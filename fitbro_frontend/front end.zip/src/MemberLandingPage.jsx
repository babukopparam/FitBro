import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

export default function MemberLandingPage() {
  const { memberId } = useParams();  // URL must contain memberId
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchLandingInfo = async () => {
      try {
        const res = await axios.get(`http://localhost:8000/members/${memberId}/landing-info`);
        setInfo(res.data);
      } catch (err) {
        console.error("Failed to load member landing info:", err);
        setInfo(null);
      } finally {
        setLoading(false);
      }
    };

    fetchLandingInfo();
  }, [memberId]);

  const handleNext = () => {
    navigate(`/log-workout/member/${memberId}`);  // will enhance this path later
  };

  if (loading) return <p className="text-center mt-10 text-gray-500">Loading...</p>;

  if (!info) {
    return <p className="text-center mt-10 text-red-500">Could not load landing info.</p>;
  }

  return (
    <div className="min-h-screen bg-white flex flex-col items-center p-6">
      {/* Gym Logo */}
      {info.gym_logo_url && (
        <img src={info.gym_logo_url} alt="Gym Logo" className="h-24 mb-4" />
      )}

      {/* Welcome & Goal */}
      <h1 className="text-2xl font-semibold mb-2">Welcome, {info.member_name}!</h1>
      <p className="text-lg text-gray-600 mb-6">Your Fitness Goal: <strong>{info.goal}</strong></p>

      {/* Promotions */}
      <div className="w-full max-w-xl space-y-4 mb-6">
        {info.promotions.map((promo, i) => (
          <div key={i} className="bg-blue-50 border-l-4 border-blue-500 text-blue-800 p-4 rounded shadow">
            <p>{promo}</p>
          </div>
        ))}
      </div>

      {/* Next Button */}
      <button
        onClick={handleNext}
        className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700"
      >
        Next
      </button>
    </div>
  );
}

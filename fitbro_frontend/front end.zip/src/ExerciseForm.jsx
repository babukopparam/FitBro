﻿// src/ExerciseForm.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ExerciseForm() {
    const [form, setForm] = useState({
        name: "",
        description: "",
        difficulty_level: "",
        demo_video_url: "",
        active: true,
        equipment: "",
        goal_tags: "",
        is_time_based: false,  // ✅ added
        workout_id: "",
        format_id: ""
    });

    const [formats, setFormats] = useState([]);
    const [workouts, setWorkouts] = useState([]);
    const [message, setMessage] = useState("");

    useEffect(() => {
        axios.get("http://localhost:8000/formats")
            .then(res => setFormats(res.data))
            .catch(console.error);
    }, []);

    const handleFormatChange = async (formatId) => {
        setForm({ ...form, format_id: formatId, workout_id: "" });
        try {
            const res = await axios.get(`http://localhost:8000/workouts/by-format/${formatId}`);
            setWorkouts(res.data);
        } catch (err) {
            console.error("Failed to load workouts", err);
        }
    };

    const handleSubmit = async () => {
        const payload = {
            name: form.name,
            description: form.description,
            difficulty_level: form.difficulty_level,
            demo_video_url: form.demo_video_url,
            active: form.active,
            equipment: form.equipment,
            goal_tags: form.goal_tags,
            is_time_based: form.is_time_based,  // ✅ include in payload
            workout_id: form.workout_id ? parseInt(form.workout_id) : null,
        };

        try {
            await axios.post("http://localhost:8000/exercises", payload);
            setMessage("✅ Exercise added successfully!");
            setForm({
                name: "",
                description: "",
                difficulty_level: "",
                demo_video_url: "",
                active: true,
                equipment: "",
                goal_tags: "",
                is_time_based: false,
                workout_id: "",
                format_id: ""
            });
            setWorkouts([]);
        } catch (error) {
            console.error("Error creating exercise:", error);
            setMessage("❌ Failed to create exercise. Check console.");
        }
    };

    return (
        <div className="p-6 max-w-xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">➕ Add Exercise</h2>

            {message && (
                <div className={`p-2 mb-4 rounded ${message.startsWith("✅") ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                    {message}
                </div>
            )}

            <div className="space-y-4">

                {/* Format Dropdown */}
                <select className="w-full p-2 border rounded" value={form.format_id}
                    onChange={(e) => handleFormatChange(e.target.value)}>
                    <option value="">Select Format</option>
                    {formats.map(f => (
                        <option key={f.id} value={f.id}>{f.name}</option>
                    ))}
                </select>

                {/* Workout Dropdown */}
                <select className="w-full p-2 border rounded" value={form.workout_id}
                    onChange={(e) => setForm({ ...form, workout_id: e.target.value })}>
                    <option value="">Select Workout</option>
                    {workouts.map(w => (
                        <option key={w.id} value={w.id}>{w.name}</option>
                    ))}
                </select>

                <input className="w-full p-2 border rounded" placeholder="Exercise Name"
                    value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />

                <textarea className="w-full p-2 border rounded" placeholder="Description"
                    value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />

                <input className="w-full p-2 border rounded" placeholder="Difficulty Level"
                    value={form.difficulty_level} onChange={e => setForm({ ...form, difficulty_level: e.target.value })} />

                <input className="w-full p-2 border rounded" placeholder="Demo Video URL"
                    value={form.demo_video_url} onChange={e => setForm({ ...form, demo_video_url: e.target.value })} />

                <input className="w-full p-2 border rounded" placeholder="Equipment"
                    value={form.equipment} onChange={e => setForm({ ...form, equipment: e.target.value })} />

                <input className="w-full p-2 border rounded" placeholder="Goal Tags (comma separated)"
                    value={form.goal_tags} onChange={e => setForm({ ...form, goal_tags: e.target.value })} />

                <div className="flex items-center">
                    <input
                        type="checkbox"
                        checked={form.is_time_based}
                        onChange={e => setForm({ ...form, is_time_based: e.target.checked })}
                        className="mr-2"
                    />
                    <label>Time-based exercise (measured in minutes)</label>
                </div>

                <button onClick={handleSubmit} className="bg-blue-600 text-white px-4 py-2 rounded">
                    Save
                </button>
            </div>
        </div>
    );
}

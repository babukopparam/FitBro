import React, { useEffect, useState } from "react";
import axios from "axios";

function Dashboard() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    axios.get("http://localhost:8000/dashboard").then((res) => {
      setStats(res.data);
    });
  }, []);

  if (!stats) return <p className="text-lg">Loading dashboard...</p>;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
      {Object.entries(stats).map(([key, value]) => (
        <div key={key} className="bg-white shadow rounded p-6">
          <h2 className="text-xl font-bold capitalize text-gray-700">{key.replace(/_/g, ' ')}</h2>
          <p className="text-3xl mt-2 text-indigo-600 font-bold">{value}</p>
        </div>
      ))}
    </div>
  );
}

export default Dashboard;

﻿// ExercisePlanForm.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ExercisePlanForm() {
    const [members, setMembers] = useState([]);
    const [formats, setFormats] = useState([]);
    const [workouts, setWorkouts] = useState({});
    const [exercisesByWorkout, setExercisesByWorkout] = useState({});
    const [plan, setPlan] = useState({});
    const [selectedMemberId, setSelectedMemberId] = useState("");
    const [cycleNumber, setCycleNumber] = useState(1);
    const [isCompleted, setIsCompleted] = useState(false);

    useEffect(() => {
        axios.get("http://localhost:8000/members").then(res => setMembers(res.data));
        axios.get("http://localhost:8000/formats").then(res => setFormats(res.data));
    }, []);

    useEffect(() => {
        if (selectedMemberId && cycleNumber) {
            fetchPlan();
        }
    }, [selectedMemberId, cycleNumber]);

    const fetchPlan = async () => {
        try {
            const res = await axios.get(`http://localhost:8000/exercise-plan/member/${selectedMemberId}/cycle/${cycleNumber}`);
            const entries = res.data;
            setIsCompleted(entries.length > 0 && entries[0].cycle_completed);

            const newPlan = {};
            const newWorkouts = {};
            const newExercises = {};

            for (const entry of entries) {
                const day = entry.day_number;
                if (!newPlan[day]) {
                    newPlan[day] = {
                        workout_id: entry.workout_id,
                        exercises: [],
                        format_id: entry.format?.id || null
                    };
                }

                newPlan[day].exercises.push({
                    exercise_id: entry.exercise_id,
                    sets: entry.sets,
                    reps: entry.reps,
                    time_minutes: entry.time_minutes
                });

                if (entry.format?.id && !newWorkouts[day]) {
                    const workoutsRes = await axios.get(`http://localhost:8000/workouts/by-format/${entry.format.id}`);
                    newWorkouts[day] = workoutsRes.data;
                }

                if (entry.workout_id && !newExercises[day]) {
                    const exercisesRes = await axios.get(`http://localhost:8000/workouts/${entry.workout_id}/exercises`);
                    newExercises[day] = exercisesRes.data;
                }
            }

            setPlan(newPlan);
            setWorkouts(newWorkouts);
            setExercisesByWorkout(newExercises);
        } catch {
            setPlan({});
            setIsCompleted(false);
        }
    };

    const handleFormatChange = async (formatId, day) => {
        const res = await axios.get(`http://localhost:8000/workouts/by-format/${formatId}`);
        setWorkouts(prev => ({ ...prev, [day]: res.data }));
        setPlan(prev => ({
            ...prev,
            [day]: { ...prev[day], workout_id: "", exercises: [], format_id: formatId }
        }));
    };

    const handleWorkoutChange = async (workoutId, day) => {
        const res = await axios.get(`http://localhost:8000/workouts/${workoutId}/exercises`);
        setExercisesByWorkout(prev => ({ ...prev, [day]: res.data }));
        setPlan(prev => ({ ...prev, [day]: { ...prev[day], workout_id: workoutId, exercises: [] } }));
    };

    const toggleExercise = (day, exercise) => {
        const dayPlan = plan[day] || { exercises: [] };
        const exists = dayPlan.exercises.find(e => e.exercise_id === exercise.id);
        const updated = exists
            ? dayPlan.exercises.filter(e => e.exercise_id !== exercise.id)
            : [...dayPlan.exercises, exercise.is_time_based
                ? { exercise_id: exercise.id, time_minutes: 10 }
                : { exercise_id: exercise.id, sets: 3, reps: 10 }];

        setPlan(prev => ({ ...prev, [day]: { ...dayPlan, exercises: updated } }));
    };

    const updateField = (day, exerciseId, field, value) => {
        const exercises = plan[day].exercises.map(e =>
            e.exercise_id === exerciseId ? { ...e, [field]: parseInt(value) } : e
        );
        setPlan(prev => ({ ...prev, [day]: { ...prev[day], exercises } }));
    };

    const handleSubmit = async () => {
        const planEntries = [];
        const memberId = parseInt(selectedMemberId); // ✅ ensure it's an integer

        Object.entries(plan).forEach(([day, data]) => {
            if (data.exercises && data.exercises.length > 0) {
                data.exercises.forEach(ex => {
                    planEntries.push({
                        member_id: parseInt(selectedMemberId),
                        cycle_number: parseInt(cycleNumber),
                        day_number: parseInt(day),
                        workout_focus: `Day ${day} Focus`,
                        workout_id: data.workout_id,
                        exercise_id: ex.exercise_id,
                        sets: ex.sets || null,
                        reps: ex.reps || null,
                        time_minutes: ex.time_minutes || null,
                        weight: null,
                        notes: null
                    });
                });
            }
        });

        try {
            await axios.post("http://localhost:8000/exercise-plan/bulk", planEntries);
            alert("Exercise plan saved successfully!");
            await fetchPlan(); // ✅ reload updated plan
        } catch (err) {
            console.error(err);
            alert("Error saving plan.");
        }
    };

    return (
        <div className="p-6 max-w-5xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">📝 Exercise Plan</h2>

            <div className="flex space-x-4 mb-4">
                <select className="p-2 border rounded" value={selectedMemberId} onChange={e => setSelectedMemberId(e.target.value)}>
                    <option value="">Select Member</option>
                    {members.map(m => (
                        <option key={m.id} value={m.id}>{m.first_name} {m.last_name}</option>
                    ))}
                </select>

                <select className="p-2 border rounded" value={cycleNumber} onChange={e => setCycleNumber(e.target.value)}>
                    {[1, 2, 3, 4, 5].map(n => (
                        <option key={n} value={n}>Cycle {n}</option>
                    ))}
                </select>

                {isCompleted && (
                    <span className="text-red-500 font-semibold">✔️ Cycle completed</span>
                )}
            </div>

            {[...Array(10)].map((_, i) => {
                const day = i + 1;
                const dayPlan = plan[day] || {};

                return (
                    <div key={day} className="border p-4 mb-6 rounded">
                        <h3 className="text-lg font-semibold mb-2">Day {day}</h3>

                        <select className="p-2 border rounded mr-2" disabled={isCompleted} value={dayPlan.format_id || ""} onChange={e => handleFormatChange(e.target.value, day)}>
                            <option value="">Select Format</option>
                            {formats.map(f => (
                                <option key={f.id} value={f.id}>{f.name}</option>
                            ))}
                        </select>

                        <select className="p-2 border rounded" disabled={isCompleted} value={dayPlan.workout_id || ""} onChange={e => handleWorkoutChange(e.target.value, day)}>
                            <option value="">Select Workout</option>
                            {(workouts[day] || []).map(w => (
                                <option key={w.id} value={w.id}>{w.name}</option>
                            ))}
                        </select>

                        <div className="mt-4">
                            {(exercisesByWorkout[day] || []).map(ex => {
                                const selected = (dayPlan.exercises || []).find(e => e.exercise_id === ex.id);
                                return (
                                    <div key={ex.id} className="flex items-center space-x-4 mb-2">
                                        <input type="checkbox" disabled={isCompleted} checked={!!selected} onChange={() => toggleExercise(day, ex)} />
                                        <span className="w-48 font-medium">{ex.name}</span>
                                        <span className="text-sm text-gray-500">{ex.description}</span>
                                        {selected && (
                                            ex.is_time_based ? (
                                                <input type="number" className="w-24 p-1 border rounded" disabled={isCompleted} value={selected.time_minutes} onChange={e => updateField(day, ex.id, "time_minutes", e.target.value)} placeholder="Minutes" />
                                            ) : (
                                                <>
                                                    <input type="number" className="w-16 p-1 border rounded" disabled={isCompleted} value={selected.sets} onChange={e => updateField(day, ex.id, "sets", e.target.value)} />
                                                    <input type="number" className="w-16 p-1 border rounded" disabled={isCompleted} value={selected.reps} onChange={e => updateField(day, ex.id, "reps", e.target.value)} />
                                                </>
                                            )
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                );
            })}

            {!isCompleted && (
                <button onClick={handleSubmit} className="bg-green-600 text-white px-6 py-2 rounded">
                    Save Plan
                </button>
            )}
        </div>
    );
}

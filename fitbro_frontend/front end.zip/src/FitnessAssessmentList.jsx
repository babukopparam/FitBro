// src/FitnessAssessmentList.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";

function FitnessAssessmentList() {
  const [assessments, setAssessments] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8000/assessments").then(res => setAssessments(res.data));
  }, []);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-purple-700">📝 Fitness Assessments</h2>
      <table className="w-full border-collapse border">
        <thead className="bg-gray-200">
          <tr>
            <th className="border p-2">ID</th>
            <th className="border p-2">Member ID</th>
            <th className="border p-2">Cycle</th>
            <th className="border p-2">Height</th>
            <th className="border p-2">Weight</th>
            <th className="border p-2">BMI</th>
            <th className="border p-2">Age</th>
            <th className="border p-2">Squats</th>
            <th className="border p-2">Pushups</th>
            <th className="border p-2">Treadmill</th>
            <th className="border p-2">Cycling</th>
            <th className="border p-2">Plank</th>
            <th className="border p-2">Lunges</th>
            <th className="border p-2">Leg Stand</th>
          </tr>
        </thead>
        <tbody>
          {assessments.map(a => (
            <tr key={a.id}>
              <td className="border p-2">{a.id}</td>
              <td className="border p-2">{a.member_id}</td>
              <td className="border p-2">{a.cycle_number}</td>
              <td className="border p-2">{a.height}</td>
              <td className="border p-2">{a.weight}</td>
              <td className="border p-2">{a.bmi}</td>
              <td className="border p-2">{a.age}</td>
              <td className="border p-2">{a.squats}</td>
              <td className="border p-2">{a.pushups}</td>
              <td className="border p-2">{a.treadmill_distance}</td>
              <td className="border p-2">{a.cycling_distance}</td>
              <td className="border p-2">{a.plank_duration}</td>
              <td className="border p-2">{a.lunges}</td>
              <td className="border p-2">{a.single_leg_stand}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default FitnessAssessmentList;

// TrainerTipsPage.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

export default function TrainerTipsPage() {
  const { memberId } = useParams();
  const [tips, setTips] = useState([]);

  useEffect(() => {
    axios
      .get(`http://localhost:8000/members/${memberId}/tips`)
      .then((res) => setTips(res.data.tips))
      .catch((err) => {
        console.error("Error loading trainer tips:", err);
        setTips([]);
      });
  }, [memberId]);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-3xl mx-auto bg-white p-6 shadow rounded">
        <h2 className="text-2xl font-bold mb-4">Trainer Tips</h2>
        {tips.length === 0 ? (
          <p className="text-gray-500">No tips available.</p>
        ) : (
          <ul className="space-y-4 list-disc list-inside">
            {tips.map((tip, idx) => (
              <li key={idx} className="text-gray-700">
                {tip}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

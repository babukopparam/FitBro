﻿import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ExerciseList() {
    const [exercises, setExercises] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        axios
            .get("http://localhost:8000/exercises")
            .then(res => {
                setExercises(res.data);
            })
            .catch(err => {
                console.error(err);
                setError("Failed to load exercises");
            })
            .finally(() => {
                setLoading(false);
            });
    }, []);

    if (loading) return <p className="p-6">Loading exercises…</p>;
    if (error) return <p className="p-6 text-red-600">{error}</p>;

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">📋 All Exercises</h2>
            {exercises.length === 0 ? (
                <p className="text-gray-600">No exercises found.</p>
            ) : (
                <table className="w-full table-auto bg-white shadow rounded">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="px-4 py-2 text-left">Name</th>
                            <th className="px-4 py-2 text-left">Equipment</th>
                            <th className="px-4 py-2 text-left">Time‑Based?</th>
                            <th className="px-4 py-2 text-left">Workout</th>
                        </tr>
                    </thead>
                    <tbody>
                        {exercises.map(ex => (
                            <tr key={ex.id} className="border-t">
                                <td className="px-4 py-2">{ex.name}</td>
                                <td className="px-4 py-2">{ex.equipment || "-"}</td>
                                <td className="px-4 py-2">
                                    {ex.is_time_based ? "✅ Yes" : "❌ No"}
                                </td>
                                <td className="px-4 py-2">
                                    {ex.workout_id ? `#${ex.workout_id}` : "-"}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
}

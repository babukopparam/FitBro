// src/WorkoutLogForm.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function WorkoutLogForm() {
    const [members, setMembers] = useState([]);
    const [selectedMemberId, setSelectedMemberId] = useState("");
    const [cycleNumber, setCycleNumber] = useState(1);
    const [planEntries, setPlanEntries] = useState([]);
    const [workoutLogs, setWorkoutLogs] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/members").then(res => setMembers(res.data));
    }, []);

    useEffect(() => {
        if (selectedMemberId && cycleNumber) {
            axios.get(`http://localhost:8000/exercise-plan/member/${selectedMemberId}/cycle/${cycleNumber}`)
                .then(res => setPlanEntries(res.data))
                .catch(() => setPlanEntries([]));

            axios.get("http://localhost:8000/workout-logs")
                .then(res => setWorkoutLogs(res.data));
        }
    }, [selectedMemberId, cycleNumber]);

    const getExercisesForDay = (day) => {
        return planEntries.filter(e => e.day_number === day);
    };

    const getWorkoutName = (entries) => {
        const names = new Set(entries.map(e => e.workout?.name).filter(Boolean));
        return Array.from(names).join(", ");
    };

    const getDayStatus = (entries) => {
        const dayLogs = entries.map(e =>
            workoutLogs.find(w => w.plan_entry_id === e.id)
        ).filter(Boolean);

        if (entries.length === 0) return { label: "Exercises are not defined", color: "text-gray-500" };

        if (dayLogs.length === entries.length && dayLogs.every(log => log.status === "done")) {
            const latestDate = getLastLoggedDate(dayLogs);
            return { label: `Completed on ${latestDate}`, color: "text-green-600" };
        }

        if (dayLogs.length > 0) {
            const latestDate = getLastLoggedDate(dayLogs);
            return { label: `Partial (last: ${latestDate})`, color: "text-yellow-600" };
        }

        return { label: "Pick up today", color: "text-blue-600" };
    };

    const getLastLoggedDate = (logs) => {
        const dates = logs.map(l => new Date(l.date));
        const latest = new Date(Math.max(...dates));
        return latest.toISOString().split("T")[0];
    };

    const handleLogChange = async (plan_entry_id, status) => {
        const date = new Date().toISOString().split("T")[0];

        try {
            await axios.post("http://localhost:8000/workout-logs/", {
                member_id: parseInt(selectedMemberId),
                plan_entry_id,
                date,
                status
            });
            const res = await axios.get("http://localhost:8000/workout-logs");
            setWorkoutLogs(res.data);
        } catch (err) {
            console.error(err);
            alert("Error logging workout.");
        }
    };

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">💪 Log Workout</h2>

            <div className="flex space-x-4 mb-4">
                <select className="p-2 border rounded" value={selectedMemberId} onChange={e => setSelectedMemberId(e.target.value)}>
                    <option value="">Select Member</option>
                    {members.map(m => (
                        <option key={m.id} value={m.id}>{m.first_name} {m.last_name}</option>
                    ))}
                </select>

                <select className="p-2 border rounded" value={cycleNumber} onChange={e => setCycleNumber(e.target.value)}>
                    {[1, 2, 3, 4, 5].map(num => (
                        <option key={num} value={num}>Cycle {num}</option>
                    ))}
                </select>
            </div>

            {[...Array(10)].map((_, i) => {
                const day = i + 1;
                const entries = getExercisesForDay(day);
                const workoutName = getWorkoutName(entries);
                const statusInfo = getDayStatus(entries);

                return (
                    <div key={day} className="border p-4 rounded mb-4">
                        <h3 className="text-lg font-bold mb-2">
                            Day {day} {workoutName && `- ${workoutName}`} <span className={`${statusInfo.color} font-semibold`}>({statusInfo.label})</span>
                        </h3>

                        {entries.length > 0 ? (
                            <table className="w-full text-sm border">
                                <thead>
                                    <tr className="bg-gray-100">
                                        <th className="p-2 text-left">Exercise</th>
                                        <th className="p-2">Sets</th>
                                        <th className="p-2">Reps</th>
                                        <th className="p-2">Duration (min)</th>
                                        <th className="p-2">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {entries.map(entry => {
                                        const existingLog = workoutLogs.find(log => log.plan_entry_id === entry.id);
                                        return (
                                            <tr key={entry.id} className="border-t">
                                                <td className="p-2">{entry.exercise?.name}</td>
                                                <td className="p-2 text-center">{entry.exercise?.is_time_based ? '-' : entry.sets}</td>
                                                <td className="p-2 text-center">{entry.exercise?.is_time_based ? '-' : entry.reps}</td>
                                                <td className="p-2 text-center">{entry.exercise?.is_time_based ? (entry.time_minutes || 0) : '-'}</td>
                                                <td className="p-2 text-center">
                                                    <select
                                                        value={existingLog?.status || "to be started"}
                                                        onChange={(e) => handleLogChange(entry.id, e.target.value)}
                                                        className="border px-2 py-1 rounded"
                                                    >
                                                        <option value="to be started">To be started</option>
                                                        <option value="done">Done</option>
                                                        <option value="partial">Partial</option>
                                                    </select>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        ) : (
                            <p className="text-gray-500 italic">No exercises defined for this day.</p>
                        )}
                    </div>
                );
            })}
        </div>
    );
}

﻿import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function MemberList() {
    const [members, setMembers] = useState([]);

    useEffect(() => {
        fetchMembers();
    }, []);

    const fetchMembers = async () => {
        try {
            const response = await axios.get('http://localhost:8000/members');
            setMembers(response.data);
        } catch (error) {
            console.error('Error fetching members:', error);
        }
    };

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h1 className="text-2xl font-bold mb-4 text-purple-800">📋 Member List</h1>
            <table className="w-full border border-gray-300 text-sm text-left">
                <thead className="bg-gray-100">
                    <tr>
                        <th className="p-2 border">First Name</th>
                        <th className="p-2 border">Last Name</th>
                        <th className="p-2 border">Mobile</th>
                        <th className="p-2 border">Email</th>
                        <th className="p-2 border">Goal</th>
                        <th className="p-2 border">Valid From</th>
                        <th className="p-2 border">Valid To</th>
                    </tr>
                </thead>
                <tbody>
                    {members.map((m) => (
                        <tr key={m.id} className="hover:bg-gray-50">
                            <td className="p-2 border">{m.first_name}</td>
                            <td className="p-2 border">{m.last_name}</td>
                            <td className="p-2 border">{m.mobile}</td>
                            <td className="p-2 border">{m.email}</td>
                            <td className="p-2 border">{m.fitness_goal}</td>
                            <td className="p-2 border">{m.valid_from}</td>
                            <td className="p-2 border">{m.valid_to}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

import React, { useState } from "react";
import axios from "axios";

export default function FormatForm() {
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [successMessage, setSuccessMessage] = useState("");

    const handleSubmit = async () => {
        try {
            await axios.post("http://localhost:8000/formats", { name, description });
            setSuccessMessage("✅ Format added successfully!");
            setName("");
            setDescription("");
        } catch (err) {
            console.error(err);
            setSuccessMessage("❌ Failed to add format. Try again.");
        }

        setTimeout(() => setSuccessMessage(""), 4000); // Clear after 4 seconds
    };

    return (
        <div className="p-6 max-w-xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">➕ Add Format</h2>

            <input
                type="text"
                className="w-full p-2 border rounded mb-3"
                placeholder="Format Name"
                value={name}
                onChange={e => setName(e.target.value)}
            />

            <textarea
                className="w-full p-2 border rounded mb-3"
                placeholder="Description (optional)"
                value={description}
                onChange={e => setDescription(e.target.value)}
            />

            <button
                onClick={handleSubmit}
                className="bg-blue-600 text-white px-4 py-2 rounded"
            >
                Save
            </button>

            {successMessage && (
                <div className={`mt-4 text-sm font-medium ${successMessage.startsWith("✅") ? "text-green-600" : "text-red-600"}`}>
                    {successMessage}
                </div>
            )}
        </div>
    );
}

import React, { useEffect, useState } from "react";
import axios from "axios";

export default function WorkoutForm() {
    const [form, setForm] = useState({
        name: "",
        format_id: ""
    });

    const [formats, setFormats] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/formats")
            .then(res => setFormats(res.data))
            .catch(console.error);
    }, []);

    const handleSubmit = async () => {
        const payload = {
            name: form.name,
            format_id: parseInt(form.format_id)
        };

        try {
            await axios.post("http://localhost:8000/workouts", payload);
            alert("Workout added!");
            setForm({ name: "", format_id: "" });
        } catch (err) {
            console.error("Error adding workout:", err);
            alert("Error: " + err.message);
        }
    };

    return (
        <div className="p-4 max-w-xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">➕ Add Workout</h2>
            <div className="space-y-4">
                <input
                    className="w-full p-2 border rounded"
                    placeholder="Workout Name"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                />

                <select
                    className="w-full p-2 border rounded"
                    value={form.format_id}
                    onChange={(e) => setForm({ ...form, format_id: e.target.value })}
                >
                    <option value="">Select Format</option>
                    {formats.map(f => (
                        <option key={f.id} value={f.id}>{f.name}</option>
                    ))}
                </select>

                <button
                    className="bg-blue-600 text-white px-4 py-2 rounded"
                    onClick={handleSubmit}
                >
                    Save
                </button>
            </div>
        </div>
    );
}

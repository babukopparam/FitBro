// LandingPage.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

export default function LandingPage() {
  const { memberId } = useParams();
  const navigate = useNavigate();

  const [info, setInfo] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:8000/members/${memberId}/landing-info`)
      .then(res => setInfo(res.data))
      .catch(err => console.error("Error fetching landing info", err));
  }, [memberId]);

  if (!info) {
    return <div className="p-8 text-center text-gray-600">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6">
      <img src={info.gym_logo_url} alt="Gym Logo" className="w-32 h-32 object-contain mb-4" />
      <h1 className="text-3xl font-bold mb-2">Welcome, {info.member_name}!</h1>
      <p className="text-lg text-gray-600 mb-6">Your Goal: <span className="font-semibold text-blue-600">{info.goal}</span></p>

      <div className="w-full max-w-md bg-blue-50 border border-blue-200 p-4 rounded-lg shadow mb-4">
        <h2 className="text-md font-semibold text-blue-700 mb-2">Promotions</h2>
        <ul className="list-disc list-inside text-sm text-gray-700">
          {info.promotions.map((promo, idx) => (
            <li key={idx}>{promo}</li>
          ))}
        </ul>
      </div>

      <button
        onClick={() => navigate(`/log-workout/member/${memberId}`)}
        className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
      >
        Next</button>
    </div>
  );
}

import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import {
  LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer
} from "recharts";

export default function AssessmentGraphPage() {
  const { memberId } = useParams();
  const [data, setData] = useState([]);
  const [view, setView] = useState("graph"); // graph or table

  useEffect(() => {
    axios
      .get(`http://localhost:8000/members/${memberId}/assessments`)
      .then((res) => setData(res.data))
      .catch((err) => console.error("Error loading assessments", err));
  }, [memberId]);

  return (
    <div className="p-6 min-h-screen bg-gray-50">
      <h2 className="text-xl font-semibold mb-4 text-center">Fitness Assessments</h2>

      <div className="text-center mb-4">
        <button
          className={`px-4 py-2 rounded-l ${view === "graph" ? "bg-blue-600 text-white" : "bg-white border"}`}
          onClick={() => setView("graph")}
        >
          Graph View
        </button>
        <button
          className={`px-4 py-2 rounded-r ${view === "table" ? "bg-blue-600 text-white" : "bg-white border"}`}
          onClick={() => setView("table")}
        >
          Tabular View
        </button>
      </div>

      {view === "graph" ? (
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
            <CartesianGrid stroke="#ccc" strokeDasharray="5 5" />
            <XAxis dataKey="cycle" label={{ value: "Cycle", position: "insideBottom", offset: -5 }} />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="weight" stroke="#8884d8" name="Weight (kg)" />
            <Line type="monotone" dataKey="bmi" stroke="#82ca9d" name="BMI" />
            <Line type="monotone" dataKey="squats_per_min" stroke="#ff7300" name="Squats/Min" />
            <Line type="monotone" dataKey="treadmill_distance" stroke="#00c49f" name="Treadmill Distance (km)" />
          </LineChart>
        </ResponsiveContainer>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border rounded">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2">Cycle</th>
                <th className="px-4 py-2">Weight</th>
                <th className="px-4 py-2">BMI</th>
                <th className="px-4 py-2">Squats/Min</th>
                <th className="px-4 py-2">Treadmill Distance</th>
              </tr>
            </thead>
            <tbody>
              {data.map((entry) => (
                <tr key={entry.cycle} className="text-center border-t">
                  <td className="px-4 py-2">{entry.cycle}</td>
                  <td className="px-4 py-2">{entry.weight}</td>
                  <td className="px-4 py-2">{entry.bmi}</td>
                  <td className="px-4 py-2">{entry.squats_per_min}</td>
                  <td className="px-4 py-2">{entry.treadmill_distance}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

﻿// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

// Admin pages
import Dashboard from "./Dashboard";
import GymForm from "./GymForm";
import GymList from "./GymList";
import VisitorForm from "./VisitorForm";
import VisitorList from "./VisitorList";
import MemberForm from "./MemberForm";
import MemberList from "./MemberList";
import FitnessAssessmentForm from "./FitnessAssessmentForm";
import ExerciseForm from "./ExerciseForm";
import ExerciseList from "./ExerciseList";
import FormatForm from "./FormatForm";
import FormatList from "./FormatList";
import WorkoutForm from "./WorkoutForm";
import WorkoutList from "./WorkoutList";
import ExercisePlanForm from "./ExercisePlanForm";
import WorkoutStatusPage from "./WorkoutStatusPage";
import LogWorkoutForDay from "./LogWorkoutForDay";

// Member‑facing/demo pages
import MemberLandingPage from "./MemberLandingPage";
import AssessmentHistoryPage from "./AssessmentHistoryPage";
import AnnouncementsPage from "./AnnouncementsPage";
import WeeklySummaryPage from "./WeeklySummaryPage";
import TrainerTipsPage from "./TrainerTipsPage";

function App() {
    return (
        <Router>
            <div className="flex h-screen">
                {/* Sidebar */}
                <aside className="w-1/5 bg-gray-800 text-white p-4 overflow-y-auto">
                    <h2 className="text-2xl font-bold mb-4">🏋️ FitBro</h2>

                    {/* --- Admin Section --- */}
                    <div className="mb-6">
                        <h3 className="text-lg font-semibold mb-2 border-b border-gray-600 pb-1">Admin</h3>
                        <nav className="flex flex-col space-y-2 text-sm">
                            <Link to="/" className="p-2 hover:bg-gray-700 rounded">Dashboard</Link>

                            <Link to="/add-format" className="p-2 hover:bg-gray-700 rounded">➕ Add Format</Link>
                            <Link to="/formats" className="p-2 hover:bg-gray-700 rounded">📋 List Formats</Link>

                            <Link to="/add-workout" className="p-2 hover:bg-gray-700 rounded">➕ Add Workout</Link>
                            <Link to="/workouts" className="p-2 hover:bg-gray-700 rounded">📋 List Workouts</Link>

                            <Link to="/add-exercise" className="p-2 hover:bg-gray-700 rounded">➕ Add Exercise</Link>
                            <Link to="/exercises" className="p-2 hover:bg-gray-700 rounded">📋 List Exercises</Link>

                            <Link to="/add-gym" className="p-2 hover:bg-gray-700 rounded">➕ Add Gym</Link>
                            <Link to="/gyms" className="p-2 hover:bg-gray-700 rounded">📋 List Gyms</Link>

                            <Link to="/add-visitor" className="p-2 hover:bg-gray-700 rounded">➕ Add Visitor</Link>
                            <Link to="/visitors" className="p-2 hover:bg-gray-700 rounded">📋 List Visitors</Link>

                            <Link to="/add-member" className="p-2 hover:bg-gray-700 rounded">➕ Add Member</Link>
                            <Link to="/members" className="p-2 hover:bg-gray-700 rounded">📋 List Members</Link>

                            <Link to="/assessments" className="p-2 hover:bg-gray-700 rounded">📋 Fitness Assessment</Link>
                            <Link to="/add-exercise-plan" className="p-2 hover:bg-gray-700 rounded">➕ Exercise Plan</Link>
                            <Link to="/log-workout" className="p-2 hover:bg-gray-700 rounded">💪 Log Workout</Link>
                        </nav>
                    </div>

                    {/* --- Member/Demo Section --- */}
                    <div>
                        <h3 className="text-lg font-semibold mb-2 border-b border-gray-600 pb-1">Member Demo</h3>
                        <nav className="flex flex-col space-y-2 text-sm">
                            <Link to="/member/1/landing" className="p-2 hover:bg-gray-700 rounded">🏠 Landing</Link>
                            <Link to="/member/1/assessments" className="p-2 hover:bg-gray-700 rounded">📊 Assessments</Link>
                            <Link to="/gym/1/announcements" className="p-2 hover:bg-gray-700 rounded">📢 Announcements</Link>
                            <Link to="/member/1/summary" className="p-2 hover:bg-gray-700 rounded">🗓 Weekly Summary</Link>
                            <Link to="/member/1/tips" className="p-2 hover:bg-gray-700 rounded">💡 Trainer Tips</Link>
                        </nav>
                    </div>
                </aside>

                {/* Main Content */}
                <main className="w-4/5 p-6 overflow-y-auto">
                    <Routes>
                        {/* Admin Routes */}
                        <Route path="/" element={<Dashboard />} />

                        <Route path="/add-format" element={<FormatForm />} />
                        <Route path="/formats" element={<FormatList />} />

                        <Route path="/add-workout" element={<WorkoutForm />} />
                        <Route path="/workouts" element={<WorkoutList />} />

                        <Route path="/add-exercise" element={<ExerciseForm />} />
                        <Route path="/exercises" element={<ExerciseList />} />

                        <Route path="/add-gym" element={<GymForm />} />
                        <Route path="/gyms" element={<GymList />} />

                        <Route path="/add-visitor" element={<VisitorForm />} />
                        <Route path="/visitors" element={<VisitorList />} />

                        <Route path="/add-member" element={<MemberForm />} />
                        <Route path="/members" element={<MemberList />} />

                        <Route path="/assessments" element={<FitnessAssessmentForm />} />
                        <Route path="/add-exercise-plan" element={<ExercisePlanForm />} />

                        <Route path="/log-workout" element={<WorkoutStatusPage />} />
                        <Route path="/log-workout/member/:memberId/cycle/:cycleNumber/day/:dayNumber"
                            element={<LogWorkoutForDay />} />

                        {/* Member Demo Routes */}
                        <Route path="/member/:memberId/landing" element={<MemberLandingPage />} />
                        <Route path="/member/:memberId/assessments" element={<AssessmentHistoryPage />} />
                        <Route path="/gym/:gymId/announcements" element={<AnnouncementsPage />} />
                        <Route path="/member/:memberId/summary" element={<WeeklySummaryPage />} />
                        <Route path="/member/:memberId/tips" element={<TrainerTipsPage />} />

                        {/* Fallback */}
                        <Route path="*" element={<div>Select a menu option from the left</div>} />
                    </Routes>
                </main>
            </div>
        </Router>
    );
}

export default App;

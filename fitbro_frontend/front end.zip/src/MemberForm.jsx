import React, { useState, useEffect } from "react";
import axios from "axios";

function MemberForm() {
    const [form, setForm] = useState({
        first_name: "",
        last_name: "",
        mobile: "",
        email: "",
        fitness_goal: "cardio",
        payment_status: "paid",
        valid_from: "",
        valid_to: "",
        govt_id_type: "aadhar",
        govt_id_number: "",
        validated_by: "instructor",
        gym_id: ""
    });
    const [gyms, setGyms] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/gyms").then((res) => setGyms(res.data));
    }, []);

    const handleSubmit = async () => {
        try {
            await axios.post("http://localhost:8000/members", form);
            alert("Member enrolled!");
            setForm({ ...form, first_name: "", last_name: "", mobile: "", email: "", govt_id_number: "" });
        } catch (err) {
            alert("Error adding member");
        }
    };

    const renderInput = (label, key, type = "text") => (
        <div className="mb-4 flex">
            <label className="w-1/3 text-right pr-4">{label}:</label>
            <input
                type={type}
                className="w-1/3 border p-1 rounded"
                value={form[key]}
                onChange={(e) => setForm({ ...form, [key]: e.target.value })}
            />
        </div>
    );

    return (
        <div className="p-6 max-w-4xl mx-auto bg-white shadow rounded">
            <h2 className="text-xl font-bold mb-4">Enroll New Member</h2>
            {renderInput("First Name", "first_name")}
            {renderInput("Last Name", "last_name")}
            {renderInput("Mobile", "mobile")}
            {renderInput("Email", "email")}
            {renderInput("Valid From", "valid_from", "date")}
            {renderInput("Valid To", "valid_to", "date")}
            {renderInput("Govt ID Number", "govt_id_number")}
            <div className="mb-4 flex">
                <label className="w-1/3 text-right pr-4">Fitness Goal:</label>
                <select className="w-1/3 border p-1 rounded" value={form.fitness_goal} onChange={(e) => setForm({ ...form, fitness_goal: e.target.value })}>
                    <option value="cardio">Cardio</option>
                    <option value="fat_loss">Fat Loss</option>
                    <option value="muscle">Muscle</option>
                </select>
            </div>
            <div className="mb-4 flex">
                <label className="w-1/3 text-right pr-4">Gym:</label>
                <select className="w-1/3 border p-1 rounded" value={form.gym_id} onChange={(e) => setForm({ ...form, gym_id: e.target.value })}>
                    <option value="">Select Gym</option>
                    {gyms.map((g) => (
                        <option key={g.id} value={g.id}>{g.name}</option>
                    ))}
                </select>
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded mt-4" onClick={handleSubmit}>Submit</button>
        </div>
    );
}

export default MemberForm;

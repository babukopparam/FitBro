import React, { useEffect, useState } from "react";
import axios from "axios";

export default function FormatList() {
  const [formats, setFormats] = useState([]);

  useEffect(() => {
    fetchFormats();
  }, []);

  const fetchFormats = async () => {
    try {
      const response = await axios.get("http://localhost:8000/formats");
      setFormats(response.data);
    } catch (error) {
      console.error("Failed to fetch formats:", error);
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h2 className="text-2xl font-semibold mb-4">📋 Format List</h2>
      {formats.length === 0 ? (
        <p className="text-gray-500">No formats available.</p>
      ) : (
        <ul className="list-disc pl-6 space-y-1">
          {formats.map((format) => (
            <li key={format.id} className="text-gray-700">
              {format.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

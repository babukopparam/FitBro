import React, { useEffect, useState } from "react";
import axios from "axios";

export default function WorkoutList() {
    const [workouts, setWorkouts] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/workouts")
            .then(res => setWorkouts(res.data))
            .catch(console.error);
    }, []);

    return (
        <div className="p-4">
            <h2 className="text-2xl font-bold mb-4">🏋️ Workouts List</h2>
            <table className="min-w-full bg-white border border-gray-300">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="py-2 px-4 border-b">Workout</th>
                        <th className="py-2 px-4 border-b">Format ID</th>
                    </tr>
                </thead>
                <tbody>
                    {workouts.map((w) => (
                        <tr key={w.id}>
                            <td className="py-2 px-4 border-b">{w.name}</td>
                            <td className="py-2 px-4 border-b">{w.format_id}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

// src/AssessmentHistoryPage.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function AssessmentHistoryPage() {
    const [members, setMembers] = useState([]);
    const [memberId, setMemberId] = useState("");
    const [data, setData] = useState([]);
    const [view, setView] = useState("graph");

    useEffect(() => {
        axios.get("http://localhost:8000/members").then((res) => {
            if (Array.isArray(res.data)) {
                setMembers(res.data);
            } else if (Array.isArray(res.data.members)) {
                setMembers(res.data.members);
            }
        });
    }, []);

    useEffect(() => {
        if (memberId) {
            axios.get(`http://localhost:8000/members/${memberId}/assessments`).then((res) => setData(res.data));
        }
    }, [memberId]);

    return (
        <div className="p-6 max-w-5xl mx-auto">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">📈 Member Assessment History</h2>

            <div className="mb-4">
                <label className="block mb-1 font-semibold">Select Member</label>
                <select
                    value={memberId}
                    onChange={(e) => setMemberId(e.target.value)}
                    className="p-2 border rounded w-full"
                >
                    <option value="">-- Select Member --</option>
                    {members.map((m) => (
                        <option key={m.id} value={m.id}>
                            {m.first_name} {m.last_name}
                        </option>
                    ))}
                </select>
            </div>

            {memberId && (
                <>
                    <div className="mb-4">
                        <button
                            onClick={() => setView("graph")}
                            className={`px-4 py-2 rounded mr-2 ${view === "graph" ? "bg-blue-600 text-white" : "bg-gray-300"}`}
                        >
                            Graph View
                        </button>
                        <button
                            onClick={() => setView("table")}
                            className={`px-4 py-2 rounded ${view === "table" ? "bg-blue-600 text-white" : "bg-gray-300"}`}
                        >
                            Table View
                        </button>
                    </div>

                    {view === "graph" ? (
                        <ResponsiveContainer width="100%" height={400}>
                            <LineChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="cycle" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="weight" stroke="#8884d8" name="Weight" />
                                <Line type="monotone" dataKey="bmi" stroke="#82ca9d" name="BMI" />
                                <Line type="monotone" dataKey="squats_per_min" stroke="#ffc658" name="Squats/min" />
                                <Line type="monotone" dataKey="treadmill_distance" stroke="#ff7300" name="Treadmill (km)" />
                            </LineChart>
                        </ResponsiveContainer>
                    ) : (
                        <table className="w-full mt-4 border border-gray-300">
                            <thead>
                                <tr className="bg-gray-100">
                                    <th className="border p-2">Cycle</th>
                                    <th className="border p-2">Weight</th>
                                    <th className="border p-2">BMI</th>
                                    <th className="border p-2">Squats/min</th>
                                    <th className="border p-2">Treadmill Distance</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.map((row, i) => (
                                    <tr key={i}>
                                        <td className="border p-2 text-center">{row.cycle}</td>
                                        <td className="border p-2 text-center">{row.weight}</td>
                                        <td className="border p-2 text-center">{row.bmi}</td>
                                        <td className="border p-2 text-center">{row.squats_per_min}</td>
                                        <td className="border p-2 text-center">{row.treadmill_distance}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </>
            )}
        </div>
    );
}

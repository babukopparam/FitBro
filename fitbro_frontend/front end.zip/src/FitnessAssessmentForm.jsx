import React, { useEffect, useState } from "react";
import axios from "axios";

function FitnessAssessmentForm() {
    const [form, setForm] = useState({
        member_id: "",
        cycle_number: 1,
        height: "",
        weight: "",
        bmi: "",
        age: "",
        squats: "",
        treadmill_distance: "",
        plank_duration: "",
        pushups: "",
        lunges: "",
        cycling_distance: "",
        single_leg_stand: "",
        assessment_date: new Date().toISOString().split("T")[0]  // YYYY-MM-DD
    });

    const [members, setMembers] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/members")
            .then(res => setMembers(res.data))
            .catch(err => console.error("Failed to fetch members", err));
    }, []);

    const handleSubmit = async () => {
        try {
            const payload = {
                ...form,
                height: parseFloat(form.height),
                weight: parseFloat(form.weight),
                bmi: parseFloat(form.bmi),
                age: parseInt(form.age),
                squats: parseInt(form.squats),
                treadmill_distance: parseFloat(form.treadmill_distance),
                plank_duration: parseFloat(form.plank_duration),
                pushups: parseInt(form.pushups),
                lunges: parseInt(form.lunges),
                cycling_distance: parseFloat(form.cycling_distance),
                single_leg_stand: parseFloat(form.single_leg_stand),
                cycle_number: parseInt(form.cycle_number),
            };

            await axios.post("http://localhost:8000/assessments", payload);
            alert("Assessment submitted successfully");

            setForm(prev => ({
                ...prev,
                cycle_number: prev.cycle_number + 1,
                assessment_date: new Date().toISOString().split("T")[0]
            }));
        } catch (err) {
            alert("Failed to submit assessment");
            console.error(err);
        }
    };

    const renderInput = (label, name, type = "text") => (
        <div className="mb-4 flex items-center">
            <label className="w-1/3 text-right pr-4">{label}</label>
            <input
                type={type}
                value={form[name]}
                onChange={e => setForm({ ...form, [name]: e.target.value })}
                className="w-1/3 p-2 border rounded"
            />
        </div>
    );

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-blue-700">📋 Add Fitness Assessment</h2>

            {/* Member Dropdown */}
            <div className="mb-4 flex items-center">
                <label className="w-1/3 text-right pr-4">Member</label>
                <select
                    value={form.member_id}
                    onChange={e => setForm({ ...form, member_id: e.target.value })}
                    className="w-1/3 p-2 border rounded"
                >
                    <option value="">Select Member</option>
                    {members.map(member => (
                        <option key={member.id} value={member.id}>
                            {member.first_name} {member.last_name}
                        </option>
                    ))}
                </select>
            </div>

            {/* Inputs */}
            {renderInput("Cycle Number", "cycle_number", "number")}
            {renderInput("Assessment Date", "assessment_date", "date")}
            {renderInput("Height (cm)", "height", "number")}
            {renderInput("Weight (kg)", "weight", "number")}
            {renderInput("BMI", "bmi", "number")}
            {renderInput("Age", "age", "number")}
            {renderInput("Squats (per min)", "squats", "number")}
            {renderInput("Treadmill Distance (km)", "treadmill_distance", "number")}
            {renderInput("Plank Duration (sec)", "plank_duration", "number")}
            {renderInput("Pushups", "pushups", "number")}
            {renderInput("Lunges", "lunges", "number")}
            {renderInput("Cycling Distance (km)", "cycling_distance", "number")}
            {renderInput("Single Leg Stand (sec)", "single_leg_stand", "number")}

            <div className="mt-6 text-center">
                <button
                    className="bg-green-600 text-white px-6 py-2 rounded"
                    onClick={handleSubmit}
                >
                    Submit Assessment
                </button>
            </div>
        </div>
    );
}

export default FitnessAssessmentForm;

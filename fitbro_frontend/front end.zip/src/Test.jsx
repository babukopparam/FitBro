export default function Test() {
    return (
        <div style={{ color: "black", fontSize: "24px" }}>
            Tailwind is NOT working, but React works!
        </div>
    );
}

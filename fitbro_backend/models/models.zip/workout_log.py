from sqlalchemy import Column, Integer, ForeignKey, Date, String, Text
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class WorkoutLog(Base):
    __tablename__ = "workout_logs"
    id = Column(Integer, primary_key=True)
    member_id = Column(Integer, ForeignKey("members.id"))
    cycle_plan_id = Column(Integer, ForeignKey("cycle_plans.id"))
    workout_plan_entry_id = Column(Integer, ForeignKey("workout_plan_entries.id"))
    actual_sets = Column(Integer)
    actual_reps = Column(Integer)
    actual_weight = Column(Integer, nullable=True)
    actual_minutes = Column(Integer, nullable=True)
    actual_rpe = Column(Integer, nullable=True)
    actual_notes = Column(Text, nullable=True)
    status = Column(String(32))  # Completed, Skipped, etc.
    workout_date = Column(Date)

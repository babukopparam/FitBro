from sqlalchemy import Column, Integer, String, Date, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Member(Base):
    __tablename__ = "members"
    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"))
    membership_plan_id = Column(Integer, ForeignKey("membership_plans.id"))
    name = Column(String(128))
    mobile = Column(String(20), index=True)
    email = Column(String(128))
    photo_url = Column(String(256), nullable=True)
    dob = Column(Date)
    gender = Column(String(16))
    address = Column(String(256))
    join_date = Column(Date)
    active = Column(Boolean, default=True)
    # relationships
    gym = relationship("Gym")
    membership_plan = relationship("MembershipPlan", back_populates="members")

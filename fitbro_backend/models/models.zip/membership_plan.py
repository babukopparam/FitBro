from sqlalchemy import Column, Integer, String, Text, Boolean, ForeignKey, Float
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class MembershipPlan(Base):
    __tablename__ = "membership_plans"
    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"))
    name = Column(String(128), nullable=False)
    description = Column(Text, nullable=True)
    duration_months = Column(Integer)
    price = Column(Float)
    status = Column(String(32), default="Active")
    # relationships
    gym = relationship("Gym")
    members = relationship("Member", back_populates="membership_plan")

from sqlalchemy import Column, Integer, String, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Workout(Base):
    __tablename__ = "workouts"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(128), nullable=False)
    description = Column(Text, nullable=True)
    program_id = Column(Integer, ForeignKey("programs.id"))
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=True)
    is_master = Column(Boolean, default=False)
    parent_id = Column(Integer, ForeignKey("workouts.id"), nullable=True)
    active = Column(Boolean, default=True)
    # relationships
    program = relationship("Program", back_populates="workouts")
    exercises = relationship("Exercise", back_populates="workout")
    parent = relationship("Workout", remote_side=[id])

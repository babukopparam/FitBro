from sqlalchemy import Column, Integer, String, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Program(Base):
    __tablename__ = "programs"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(128), nullable=False)
    description = Column(Text)
    goals = Column(Text, nullable=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=True)  # NULL = FitBro master
    is_master = Column(Boolean, default=False)
    parent_id = Column(Integer, ForeignKey("programs.id"), nullable=True)
    active = Column(Boolean, default=True)
    # relationships
    gym = relationship("Gym", back_populates="programs")
    workouts = relationship("Workout", back_populates="program")
    parent = relationship("Program", remote_side=[id])

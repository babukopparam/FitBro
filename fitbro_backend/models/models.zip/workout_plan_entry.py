from sqlalchemy import Column, Integer, ForeignKey, Date, String, Text
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class WorkoutPlanEntry(Base):
    __tablename__ = "workout_plan_entries"
    id = Column(Integer, primary_key=True)
    cycle_plan_id = Column(Integer, ForeignKey("cycle_plans.id"))
    day_number = Column(Integer)
    workout_id = Column(Integer, ForeignKey("workouts.id"))
    exercise_id = Column(Integer, ForeignKey("exercises.id"))
    planned_sets = Column(Integer)
    planned_reps = Column(Integer)
    planned_weight = Column(Integer, nullable=True)
    planned_minutes = Column(Integer, nullable=True)
    planned_rpe = Column(Integer, nullable=True)
    planned_notes = Column(Text, nullable=True)
    # relationships
    cycle_plan = relationship("CyclePlan")
    workout = relationship("Workout")
    exercise = relationship("Exercise")

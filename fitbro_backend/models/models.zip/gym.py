from sqlalchemy import Column, Integer, String, Date, DateTime, Boolean
from sqlalchemy.orm import relationship
from fitbro_backend.database import Base

class Gym(Base):
    __tablename__ = "gyms"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(128), nullable=False)
    address = Column(String(256), nullable=True)
    owner_mobile = Column(String(20), nullable=True)
    contract_start = Column(Date, nullable=True)
    contract_end = Column(Date, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime)
    # relationships
    users = relationship("User", back_populates="gym")
    # add other relationships as needed (e.g., equipment, members, etc.)

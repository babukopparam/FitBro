from sqlalchemy import Column, Integer, String, Boolean, Table, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

exercise_equipment = Table(
    "exercise_equipment",
    Base.metadata,
    Column("exercise_id", Integer, ForeignKey("exercises.id")),
    Column("equipment_id", Integer, ForeignKey("equipment.id")),
)

class Exercise(Base):
    __tablename__ = "exercises"
    id = Column(Integer, primary_key=True)
    name = Column(String(128), nullable=False)
    primary_muscle = Column(String(64))
    secondary_muscle = Column(String(64))
    is_master = Column(Boolean, default=True)

    equipment = relationship(
        "Equipment",
        secondary=exercise_equipment,
        back_populates="exercises"
    )

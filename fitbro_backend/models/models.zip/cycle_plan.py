from sqlalchemy import Column, Integer, String, Date, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class CyclePlan(Base):
    __tablename__ = "cycle_plans"
    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id"))
    program_id = Column(Integer, ForeignKey("programs.id"))
    cycle_number = Column(Integer)
    start_date = Column(Date)
    end_date = Column(Date)
    status = Column(String(32))  # Active, Completed, Terminated, etc.
    # relationships
    member = relationship("Member")
    program = relationship("Program")

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()

class Announcement(Base):
    __tablename__ = "announcements"
    id = Column(Integer, primary_key=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"))
    title = Column(String(128))
    message = Column(Text)
    posted_at = Column(DateTime, default=datetime.datetime.utcnow)
    created_by = Column(Integer, ForeignKey("users.id"))

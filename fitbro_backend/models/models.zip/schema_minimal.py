from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Float, Text
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(64))
    mobile = Column(String(20), unique=True)
    email = Column(String(128))
    password = Column(String(256))
    role = Column(String(32))
    gym_id = Column(Integer)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Gym(Base):
    __tablename__ = "gyms"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    address = Column(String(256))
    owner_mobile = Column(String(20))
    contract_start = Column(DateTime)
    contract_end = Column(DateTime)

class Announcement(Base):
    __tablename__ = "announcements"
    id = Column(Integer, primary_key=True)
    title = Column(String(128))
    message = Column(Text)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    gym_id = Column(Integer)

class Visitor(Base):
    __tablename__ = "visitors"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    mobile = Column(String(20))
    status = Column(String(32))
    gym_id = Column(Integer)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Program(Base):
    __tablename__ = "programs"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    description = Column(Text)
    gym_id = Column(Integer)
    is_master = Column(Boolean, default=False)
    parent_id = Column(Integer)

class Workout(Base):
    __tablename__ = "workouts"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    program_id = Column(Integer)
    gym_id = Column(Integer)

class Exercise(Base):
    __tablename__ = "exercises"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    primary_muscle = Column(String(128))
    secondary_muscle = Column(String(128))
    equipment_id = Column(Integer)
    is_master = Column(Boolean, default=False)

class Equipment(Base):
    __tablename__ = "equipment"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    gym_id = Column(Integer)
    manufacturer = Column(String(128))
    purchase_date = Column(DateTime)
    warranty_years = Column(Integer)
    status = Column(String(32))

class MembershipPlan(Base):
    __tablename__ = "membership_plans"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    gym_id = Column(Integer)
    duration = Column(String(32))
    price = Column(Integer)
    status = Column(String(32))

class Member(Base):
    __tablename__ = "members"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    mobile = Column(String(20))
    gym_id = Column(Integer)
    membership_plan_id = Column(Integer)

class CyclePlan(Base):
    __tablename__ = "cycle_plans"
    id = Column(Integer, primary_key=True)
    member_id = Column(Integer)
    cycle_number = Column(Integer)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    status = Column(String(32))

class AssessmentTemplate(Base):
    __tablename__ = "assessment_templates"
    id = Column(Integer, primary_key=True)
    name = Column(String(128))
    attributes = Column(Text)

class WorkoutPlanEntry(Base):
    __tablename__ = "workout_plan_entries"
    id = Column(Integer, primary_key=True)
    cycle_plan_id = Column(Integer)
    day_number = Column(Integer)
    workout_id = Column(Integer)
    exercise_id = Column(Integer)
    planned_sets = Column(Integer)
    planned_reps = Column(Integer)

class WorkoutLog(Base):
    __tablename__ = "workout_logs"
    id = Column(Integer, primary_key=True)
    member_id = Column(Integer)
    cycle_plan_id = Column(Integer)
    day_number = Column(Integer)
    exercise_id = Column(Integer)
    sets_completed = Column(Integer)
    reps_completed = Column(Integer)
    status = Column(String(32))
    log_date = Column(DateTime)

class AssessmentResult(Base):
    __tablename__ = "assessment_results"
    id = Column(Integer, primary_key=True)
    member_id = Column(Integer)
    template_id = Column(Integer)
    date_taken = Column(DateTime)
    values = Column(Text)

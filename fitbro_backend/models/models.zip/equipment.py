from sqlalchemy import Column, Integer, String, Boolean, Date, ForeignKey
from sqlalchemy.orm import relationship
from .exercise import exercise_equipment, Base

class Equipment(Base):
    __tablename__ = "equipment"
    id = Column(Integer, primary_key=True)
    name = Column(String(128), nullable=False)
    manufacturer = Column(String(128))
    purchase_date = Column(Date)
    warranty_years = Column(Integer)
    status = Column(String(32), default="active")
    gym_id = Column(Integer, ForeignKey("gyms.id"))  # <-- Add this!

    exercises = relationship(
        "Exercise",
        secondary=exercise_equipment,
        back_populates="equipment"
    )
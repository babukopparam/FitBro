from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()

class AssessmentResult(Base):
    __tablename__ = "assessment_results"
    id = Column(Integer, primary_key=True)
    member_id = Column(Integer, ForeignKey("members.id"))
    template_id = Column(Integer, ForeignKey("assessment_templates.id"))
    taken_at = Column(DateTime, default=datetime.datetime.utcnow)
    result_json = Column(Text)
